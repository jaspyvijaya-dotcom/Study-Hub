import { ReactNode, useState, useEffect } from "react";
import { AppSidebar } from "./AppSidebar";

export function AppLayout({ children }: { children: ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(260);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 1024);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  useEffect(() => {
    if (isMobile) { setSidebarWidth(0); return; }
    const observer = new MutationObserver(() => {
      const sidebar = document.querySelector("aside.lg\\:flex, aside:not(.lg\\:hidden)");
      if (sidebar) setSidebarWidth(sidebar.getBoundingClientRect().width);
    });
    const sidebar = document.querySelector("aside");
    if (sidebar) {
      observer.observe(sidebar, { attributes: true, attributeFilter: ["style"] });
      setSidebarWidth(sidebar.getBoundingClientRect().width);
    }
    return () => observer.disconnect();
  }, [isMobile]);

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main
        className="min-h-screen transition-all duration-300"
        style={{ marginLeft: isMobile ? 0 : sidebarWidth, paddingTop: isMobile ? 56 : 0 }}
      >
        {children}
      </main>
    </div>
  );
}
