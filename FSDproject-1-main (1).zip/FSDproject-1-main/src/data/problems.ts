export interface Problem {
  id: number;
  title: string;
  difficulty: "Easy" | "Medium" | "Hard";
  tags: string[];
  description: string;
  input: string;
  output: string;
  hints: string[];
  solutions: {
    python: string;
    java: string;
    cpp: string;
    javascript: string;
  };
  externalLink: string;
}

export const problems: Problem[] = [
  // ===== ARRAYS =====
  {
    id: 1,
    title: "Two Sum",
    difficulty: "Easy",
    tags: ["Arrays", "Hash Table"],
    description: "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.",
    input: "nums = [2,7,11,15], target = 9",
    output: "[0,1]",
    hints: ["Try using a hash map to store values you've seen.", "For each number, check if target - number exists in the map."],
    solutions: {
      python: `def twoSum(nums, target):
    seen = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in seen:
            return [seen[complement], i]
        seen[num] = i
    return []`,
      java: `public int[] twoSum(int[] nums, int target) {
    Map<Integer, Integer> map = new HashMap<>();
    for (int i = 0; i < nums.length; i++) {
        int complement = target - nums[i];
        if (map.containsKey(complement))
            return new int[]{map.get(complement), i};
        map.put(nums[i], i);
    }
    return new int[]{};
}`,
      cpp: `vector<int> twoSum(vector<int>& nums, int target) {
    unordered_map<int, int> map;
    for (int i = 0; i < nums.size(); i++) {
        int comp = target - nums[i];
        if (map.count(comp)) return {map[comp], i};
        map[nums[i]] = i;
    }
    return {};
}`,
      javascript: `function twoSum(nums, target) {
    const map = new Map();
    for (let i = 0; i < nums.length; i++) {
        const comp = target - nums[i];
        if (map.has(comp)) return [map.get(comp), i];
        map.set(nums[i], i);
    }
    return [];
}`,
    },
    externalLink: "https://leetcode.com/problems/two-sum/",
  },
  {
    id: 2,
    title: "Best Time to Buy and Sell Stock",
    difficulty: "Easy",
    tags: ["Arrays", "Dynamic Programming"],
    description: "You are given an array prices where prices[i] is the price of a given stock on the ith day. Return the maximum profit you can achieve.",
    input: "prices = [7,1,5,3,6,4]",
    output: "5",
    hints: ["Track the minimum price seen so far.", "At each step, calculate profit if you sell today."],
    solutions: {
      python: `def maxProfit(prices):
    min_price = float('inf')
    max_profit = 0
    for price in prices:
        min_price = min(min_price, price)
        max_profit = max(max_profit, price - min_price)
    return max_profit`,
      java: `public int maxProfit(int[] prices) {
    int minPrice = Integer.MAX_VALUE, maxProfit = 0;
    for (int price : prices) {
        minPrice = Math.min(minPrice, price);
        maxProfit = Math.max(maxProfit, price - minPrice);
    }
    return maxProfit;
}`,
      cpp: `int maxProfit(vector<int>& prices) {
    int minP = INT_MAX, maxP = 0;
    for (int p : prices) {
        minP = min(minP, p);
        maxP = max(maxP, p - minP);
    }
    return maxP;
}`,
      javascript: `function maxProfit(prices) {
    let minPrice = Infinity, maxProfit = 0;
    for (const price of prices) {
        minPrice = Math.min(minPrice, price);
        maxProfit = Math.max(maxProfit, price - minPrice);
    }
    return maxProfit;
}`,
    },
    externalLink: "https://leetcode.com/problems/best-time-to-buy-and-sell-stock/",
  },
  {
    id: 3,
    title: "Contains Duplicate",
    difficulty: "Easy",
    tags: ["Arrays", "Hash Table"],
    description: "Given an integer array nums, return true if any value appears at least twice in the array.",
    input: "nums = [1,2,3,1]",
    output: "true",
    hints: ["Use a Set to track seen elements.", "If you encounter an element already in the set, return true."],
    solutions: {
      python: `def containsDuplicate(nums):
    return len(nums) != len(set(nums))`,
      java: `public boolean containsDuplicate(int[] nums) {
    Set<Integer> set = new HashSet<>();
    for (int num : nums) {
        if (!set.add(num)) return true;
    }
    return false;
}`,
      cpp: `bool containsDuplicate(vector<int>& nums) {
    unordered_set<int> s(nums.begin(), nums.end());
    return s.size() != nums.size();
}`,
      javascript: `function containsDuplicate(nums) {
    return new Set(nums).size !== nums.length;
}`,
    },
    externalLink: "https://leetcode.com/problems/contains-duplicate/",
  },
  {
    id: 4,
    title: "Maximum Subarray",
    difficulty: "Medium",
    tags: ["Arrays", "Dynamic Programming"],
    description: "Given an integer array nums, find the subarray with the largest sum, and return its sum.",
    input: "nums = [-2,1,-3,4,-1,2,1,-5,4]",
    output: "6",
    hints: ["Use Kadane's algorithm.", "At each position, decide whether to extend or start a new subarray."],
    solutions: {
      python: `def maxSubArray(nums):
    max_sum = cur_sum = nums[0]
    for num in nums[1:]:
        cur_sum = max(num, cur_sum + num)
        max_sum = max(max_sum, cur_sum)
    return max_sum`,
      java: `public int maxSubArray(int[] nums) {
    int maxSum = nums[0], curSum = nums[0];
    for (int i = 1; i < nums.length; i++) {
        curSum = Math.max(nums[i], curSum + nums[i]);
        maxSum = Math.max(maxSum, curSum);
    }
    return maxSum;
}`,
      cpp: `int maxSubArray(vector<int>& nums) {
    int maxS = nums[0], curS = nums[0];
    for (int i = 1; i < nums.size(); i++) {
        curS = max(nums[i], curS + nums[i]);
        maxS = max(maxS, curS);
    }
    return maxS;
}`,
      javascript: `function maxSubArray(nums) {
    let maxSum = nums[0], curSum = nums[0];
    for (let i = 1; i < nums.length; i++) {
        curSum = Math.max(nums[i], curSum + nums[i]);
        maxSum = Math.max(maxSum, curSum);
    }
    return maxSum;
}`,
    },
    externalLink: "https://leetcode.com/problems/maximum-subarray/",
  },
  {
    id: 5,
    title: "Product of Array Except Self",
    difficulty: "Medium",
    tags: ["Arrays"],
    description: "Given an integer array nums, return an array where answer[i] is the product of all elements except nums[i], in O(n) without division.",
    input: "nums = [1,2,3,4]",
    output: "[24,12,8,6]",
    hints: ["Use prefix and suffix products.", "First pass: prefix. Second pass: multiply with suffix."],
    solutions: {
      python: `def productExceptSelf(nums):
    n = len(nums)
    res = [1] * n
    prefix = 1
    for i in range(n):
        res[i] = prefix
        prefix *= nums[i]
    suffix = 1
    for i in range(n-1, -1, -1):
        res[i] *= suffix
        suffix *= nums[i]
    return res`,
      java: `public int[] productExceptSelf(int[] nums) {
    int n = nums.length;
    int[] res = new int[n];
    res[0] = 1;
    for (int i = 1; i < n; i++) res[i] = res[i-1]*nums[i-1];
    int suf = 1;
    for (int i = n-1; i >= 0; i--) { res[i] *= suf; suf *= nums[i]; }
    return res;
}`,
      cpp: `vector<int> productExceptSelf(vector<int>& nums) {
    int n = nums.size();
    vector<int> res(n, 1);
    for (int i = 1; i < n; i++) res[i] = res[i-1]*nums[i-1];
    int suf = 1;
    for (int i = n-1; i >= 0; i--) { res[i] *= suf; suf *= nums[i]; }
    return res;
}`,
      javascript: `function productExceptSelf(nums) {
    const n = nums.length, res = Array(n).fill(1);
    let pre = 1;
    for (let i = 0; i < n; i++) { res[i] = pre; pre *= nums[i]; }
    let suf = 1;
    for (let i = n-1; i >= 0; i--) { res[i] *= suf; suf *= nums[i]; }
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/product-of-array-except-self/",
  },
  {
    id: 6,
    title: "Trapping Rain Water",
    difficulty: "Hard",
    tags: ["Arrays", "Two Pointers"],
    description: "Given n non-negative integers representing an elevation map, compute how much water it can trap after raining.",
    input: "height = [0,1,0,2,1,0,1,3,2,1,2,1]",
    output: "6",
    hints: ["Use two pointers from both ends.", "Track the max height from left and right."],
    solutions: {
      python: `def trap(height):
    l, r = 0, len(height) - 1
    lmax = rmax = water = 0
    while l < r:
        if height[l] < height[r]:
            lmax = max(lmax, height[l])
            water += lmax - height[l]; l += 1
        else:
            rmax = max(rmax, height[r])
            water += rmax - height[r]; r -= 1
    return water`,
      java: `public int trap(int[] h) {
    int l = 0, r = h.length-1, lm = 0, rm = 0, w = 0;
    while (l < r) {
        if (h[l] < h[r]) { lm = Math.max(lm, h[l]); w += lm-h[l++]; }
        else { rm = Math.max(rm, h[r]); w += rm-h[r--]; }
    }
    return w;
}`,
      cpp: `int trap(vector<int>& h) {
    int l=0, r=h.size()-1, lm=0, rm=0, w=0;
    while(l<r) {
        if(h[l]<h[r]) { lm=max(lm,h[l]); w+=lm-h[l++]; }
        else { rm=max(rm,h[r]); w+=rm-h[r--]; }
    }
    return w;
}`,
      javascript: `function trap(height) {
    let l = 0, r = height.length-1, lm = 0, rm = 0, w = 0;
    while (l < r) {
        if (height[l] < height[r]) { lm = Math.max(lm, height[l]); w += lm-height[l++]; }
        else { rm = Math.max(rm, height[r]); w += rm-height[r--]; }
    }
    return w;
}`,
    },
    externalLink: "https://leetcode.com/problems/trapping-rain-water/",
  },

  // ===== STRINGS =====
  {
    id: 7,
    title: "Valid Anagram",
    difficulty: "Easy",
    tags: ["Strings", "Hash Table"],
    description: "Given two strings s and t, return true if t is an anagram of s.",
    input: 's = "anagram", t = "nagaram"',
    output: "true",
    hints: ["Count character frequencies.", "Both strings must have identical character counts."],
    solutions: {
      python: `def isAnagram(s, t):
    return sorted(s) == sorted(t)`,
      java: `public boolean isAnagram(String s, String t) {
    char[] a = s.toCharArray(), b = t.toCharArray();
    Arrays.sort(a); Arrays.sort(b);
    return Arrays.equals(a, b);
}`,
      cpp: `bool isAnagram(string s, string t) {
    sort(s.begin(), s.end());
    sort(t.begin(), t.end());
    return s == t;
}`,
      javascript: `function isAnagram(s, t) {
    return [...s].sort().join('') === [...t].sort().join('');
}`,
    },
    externalLink: "https://leetcode.com/problems/valid-anagram/",
  },
  {
    id: 8,
    title: "Valid Palindrome",
    difficulty: "Easy",
    tags: ["Strings", "Two Pointers"],
    description: "Given a string s, return true if it is a palindrome after converting to lowercase and removing non-alphanumeric characters.",
    input: 's = "A man, a plan, a canal: Panama"',
    output: "true",
    hints: ["Use two pointers from both ends.", "Skip non-alphanumeric characters."],
    solutions: {
      python: `def isPalindrome(s):
    s = ''.join(c.lower() for c in s if c.isalnum())
    return s == s[::-1]`,
      java: `public boolean isPalindrome(String s) {
    int l = 0, r = s.length()-1;
    while (l < r) {
        while (l<r && !Character.isLetterOrDigit(s.charAt(l))) l++;
        while (l<r && !Character.isLetterOrDigit(s.charAt(r))) r--;
        if (Character.toLowerCase(s.charAt(l)) != Character.toLowerCase(s.charAt(r))) return false;
        l++; r--;
    }
    return true;
}`,
      cpp: `bool isPalindrome(string s) {
    int l=0, r=s.size()-1;
    while(l<r) {
        while(l<r && !isalnum(s[l])) l++;
        while(l<r && !isalnum(s[r])) r--;
        if(tolower(s[l])!=tolower(s[r])) return false;
        l++; r--;
    }
    return true;
}`,
      javascript: `function isPalindrome(s) {
    const clean = s.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    return clean === clean.split('').reverse().join('');
}`,
    },
    externalLink: "https://leetcode.com/problems/valid-palindrome/",
  },
  {
    id: 9,
    title: "Longest Substring Without Repeating Characters",
    difficulty: "Medium",
    tags: ["Strings", "Sliding Window"],
    description: "Given a string s, find the length of the longest substring without repeating characters.",
    input: 's = "abcabcbb"',
    output: "3",
    hints: ["Use a sliding window with a set.", "When a duplicate is found, shrink the window from the left."],
    solutions: {
      python: `def lengthOfLongestSubstring(s):
    seen = set()
    l = res = 0
    for r in range(len(s)):
        while s[r] in seen:
            seen.remove(s[l]); l += 1
        seen.add(s[r])
        res = max(res, r - l + 1)
    return res`,
      java: `public int lengthOfLongestSubstring(String s) {
    Set<Character> set = new HashSet<>();
    int l = 0, res = 0;
    for (int r = 0; r < s.length(); r++) {
        while (set.contains(s.charAt(r))) set.remove(s.charAt(l++));
        set.add(s.charAt(r));
        res = Math.max(res, r-l+1);
    }
    return res;
}`,
      cpp: `int lengthOfLongestSubstring(string s) {
    unordered_set<char> st;
    int l=0, res=0;
    for(int r=0; r<s.size(); r++) {
        while(st.count(s[r])) st.erase(s[l++]);
        st.insert(s[r]);
        res = max(res, r-l+1);
    }
    return res;
}`,
      javascript: `function lengthOfLongestSubstring(s) {
    const set = new Set();
    let l = 0, res = 0;
    for (let r = 0; r < s.length; r++) {
        while (set.has(s[r])) set.delete(s[l++]);
        set.add(s[r]);
        res = Math.max(res, r - l + 1);
    }
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/longest-substring-without-repeating-characters/",
  },
  {
    id: 10,
    title: "Longest Palindromic Substring",
    difficulty: "Medium",
    tags: ["Strings", "Dynamic Programming"],
    description: "Given a string s, return the longest palindromic substring in s.",
    input: 's = "babad"',
    output: '"bab"',
    hints: ["Expand around each center.", "Consider both odd and even length palindromes."],
    solutions: {
      python: `def longestPalindrome(s):
    res = ""
    for i in range(len(s)):
        for l, r in [(i,i), (i,i+1)]:
            while l >= 0 and r < len(s) and s[l] == s[r]:
                l -= 1; r += 1
            if r - l - 1 > len(res):
                res = s[l+1:r]
    return res`,
      java: `public String longestPalindrome(String s) {
    int start = 0, maxLen = 0;
    for (int i = 0; i < s.length(); i++) {
        int l1 = expand(s, i, i), l2 = expand(s, i, i+1);
        int len = Math.max(l1, l2);
        if (len > maxLen) { maxLen = len; start = i - (len-1)/2; }
    }
    return s.substring(start, start + maxLen);
}
int expand(String s, int l, int r) {
    while (l >= 0 && r < s.length() && s.charAt(l) == s.charAt(r)) { l--; r++; }
    return r - l - 1;
}`,
      cpp: `string longestPalindrome(string s) {
    int start=0, maxLen=0;
    auto expand = [&](int l, int r) {
        while(l>=0 && r<s.size() && s[l]==s[r]) { l--; r++; }
        if(r-l-1 > maxLen) { maxLen=r-l-1; start=l+1; }
    };
    for(int i=0; i<s.size(); i++) { expand(i,i); expand(i,i+1); }
    return s.substr(start, maxLen);
}`,
      javascript: `function longestPalindrome(s) {
    let res = "";
    for (let i = 0; i < s.length; i++) {
        for (const [a, b] of [[i,i],[i,i+1]]) {
            let l = a, r = b;
            while (l >= 0 && r < s.length && s[l] === s[r]) { l--; r++; }
            if (r-l-1 > res.length) res = s.slice(l+1, r);
        }
    }
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/longest-palindromic-substring/",
  },
  {
    id: 11,
    title: "Group Anagrams",
    difficulty: "Medium",
    tags: ["Strings", "Hash Table"],
    description: "Given an array of strings strs, group the anagrams together.",
    input: 'strs = ["eat","tea","tan","ate","nat","bat"]',
    output: '[["bat"],["nat","tan"],["ate","eat","tea"]]',
    hints: ["Sort each string to create a key.", "Use a hash map with sorted string as key."],
    solutions: {
      python: `def groupAnagrams(strs):
    groups = {}
    for s in strs:
        key = ''.join(sorted(s))
        groups.setdefault(key, []).append(s)
    return list(groups.values())`,
      java: `public List<List<String>> groupAnagrams(String[] strs) {
    Map<String, List<String>> map = new HashMap<>();
    for (String s : strs) {
        char[] c = s.toCharArray();
        Arrays.sort(c);
        String key = new String(c);
        map.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
    }
    return new ArrayList<>(map.values());
}`,
      cpp: `vector<vector<string>> groupAnagrams(vector<string>& strs) {
    unordered_map<string, vector<string>> m;
    for (auto& s : strs) { string k=s; sort(k.begin(),k.end()); m[k].push_back(s); }
    vector<vector<string>> res;
    for (auto& [k,v] : m) res.push_back(v);
    return res;
}`,
      javascript: `function groupAnagrams(strs) {
    const map = {};
    for (const s of strs) {
        const key = [...s].sort().join('');
        (map[key] ??= []).push(s);
    }
    return Object.values(map);
}`,
    },
    externalLink: "https://leetcode.com/problems/group-anagrams/",
  },

  // ===== SORTING =====
  {
    id: 12,
    title: "Merge Sorted Array",
    difficulty: "Easy",
    tags: ["Sorting", "Two Pointers"],
    description: "Merge nums2 into nums1 as one sorted array. nums1 has enough space.",
    input: "nums1 = [1,2,3,0,0,0], m=3, nums2 = [2,5,6], n=3",
    output: "[1,2,2,3,5,6]",
    hints: ["Start merging from the end.", "Use three pointers."],
    solutions: {
      python: `def merge(nums1, m, nums2, n):
    i, j, k = m-1, n-1, m+n-1
    while j >= 0:
        if i >= 0 and nums1[i] > nums2[j]:
            nums1[k] = nums1[i]; i -= 1
        else:
            nums1[k] = nums2[j]; j -= 1
        k -= 1`,
      java: `public void merge(int[] a, int m, int[] b, int n) {
    int i=m-1, j=n-1, k=m+n-1;
    while(j>=0) a[k--] = (i>=0 && a[i]>b[j]) ? a[i--] : b[j--];
}`,
      cpp: `void merge(vector<int>& a, int m, vector<int>& b, int n) {
    int i=m-1, j=n-1, k=m+n-1;
    while(j>=0) a[k--] = (i>=0 && a[i]>b[j]) ? a[i--] : b[j--];
}`,
      javascript: `function merge(nums1, m, nums2, n) {
    let i=m-1, j=n-1, k=m+n-1;
    while(j>=0) nums1[k--] = (i>=0 && nums1[i]>nums2[j]) ? nums1[i--] : nums2[j--];
}`,
    },
    externalLink: "https://leetcode.com/problems/merge-sorted-array/",
  },
  {
    id: 13,
    title: "Sort Colors",
    difficulty: "Medium",
    tags: ["Sorting", "Two Pointers"],
    description: "Given an array with n objects colored red (0), white (1), or blue (2), sort them in-place (Dutch National Flag).",
    input: "nums = [2,0,2,1,1,0]",
    output: "[0,0,1,1,2,2]",
    hints: ["Use three pointers: low, mid, high.", "This is the Dutch National Flag problem."],
    solutions: {
      python: `def sortColors(nums):
    lo, mid, hi = 0, 0, len(nums)-1
    while mid <= hi:
        if nums[mid] == 0:
            nums[lo], nums[mid] = nums[mid], nums[lo]
            lo += 1; mid += 1
        elif nums[mid] == 1: mid += 1
        else:
            nums[mid], nums[hi] = nums[hi], nums[mid]
            hi -= 1`,
      java: `public void sortColors(int[] nums) {
    int lo=0, mid=0, hi=nums.length-1;
    while(mid<=hi) {
        if(nums[mid]==0) { swap(nums,lo++,mid++); }
        else if(nums[mid]==1) mid++;
        else swap(nums,mid,hi--);
    }
}
void swap(int[] a, int i, int j) { int t=a[i]; a[i]=a[j]; a[j]=t; }`,
      cpp: `void sortColors(vector<int>& nums) {
    int lo=0, mid=0, hi=nums.size()-1;
    while(mid<=hi) {
        if(nums[mid]==0) swap(nums[lo++], nums[mid++]);
        else if(nums[mid]==1) mid++;
        else swap(nums[mid], nums[hi--]);
    }
}`,
      javascript: `function sortColors(nums) {
    let lo=0, mid=0, hi=nums.length-1;
    while(mid<=hi) {
        if(nums[mid]===0) [nums[lo],nums[mid]]=[nums[mid],nums[lo]], lo++, mid++;
        else if(nums[mid]===1) mid++;
        else [nums[mid],nums[hi]]=[nums[hi],nums[mid]], hi--;
    }
}`,
    },
    externalLink: "https://leetcode.com/problems/sort-colors/",
  },
  {
    id: 14,
    title: "Kth Largest Element in an Array",
    difficulty: "Medium",
    tags: ["Sorting", "Heap"],
    description: "Given an integer array nums and an integer k, return the kth largest element.",
    input: "nums = [3,2,1,5,6,4], k = 2",
    output: "5",
    hints: ["Use a min-heap of size k.", "Or use quickselect for average O(n)."],
    solutions: {
      python: `import heapq
def findKthLargest(nums, k):
    return heapq.nlargest(k, nums)[-1]`,
      java: `public int findKthLargest(int[] nums, int k) {
    PriorityQueue<Integer> pq = new PriorityQueue<>();
    for (int n : nums) {
        pq.offer(n);
        if (pq.size() > k) pq.poll();
    }
    return pq.peek();
}`,
      cpp: `int findKthLargest(vector<int>& nums, int k) {
    priority_queue<int, vector<int>, greater<>> pq;
    for (int n : nums) {
        pq.push(n);
        if (pq.size() > k) pq.pop();
    }
    return pq.top();
}`,
      javascript: `function findKthLargest(nums, k) {
    nums.sort((a,b) => b-a);
    return nums[k-1];
}`,
    },
    externalLink: "https://leetcode.com/problems/kth-largest-element-in-an-array/",
  },
  {
    id: 15,
    title: "Merge Intervals",
    difficulty: "Medium",
    tags: ["Sorting", "Arrays"],
    description: "Given an array of intervals, merge all overlapping intervals.",
    input: "intervals = [[1,3],[2,6],[8,10],[15,18]]",
    output: "[[1,6],[8,10],[15,18]]",
    hints: ["Sort by start time.", "Compare current interval's start with previous end."],
    solutions: {
      python: `def merge(intervals):
    intervals.sort()
    res = [intervals[0]]
    for s, e in intervals[1:]:
        if s <= res[-1][1]:
            res[-1][1] = max(res[-1][1], e)
        else:
            res.append([s, e])
    return res`,
      java: `public int[][] merge(int[][] intervals) {
    Arrays.sort(intervals, (a,b) -> a[0]-b[0]);
    List<int[]> res = new ArrayList<>();
    res.add(intervals[0]);
    for (int[] iv : intervals) {
        if (iv[0] <= res.get(res.size()-1)[1])
            res.get(res.size()-1)[1] = Math.max(res.get(res.size()-1)[1], iv[1]);
        else res.add(iv);
    }
    return res.toArray(new int[0][]);
}`,
      cpp: `vector<vector<int>> merge(vector<vector<int>>& iv) {
    sort(iv.begin(), iv.end());
    vector<vector<int>> res = {iv[0]};
    for (int i = 1; i < iv.size(); i++) {
        if (iv[i][0] <= res.back()[1]) res.back()[1] = max(res.back()[1], iv[i][1]);
        else res.push_back(iv[i]);
    }
    return res;
}`,
      javascript: `function merge(intervals) {
    intervals.sort((a,b) => a[0]-b[0]);
    const res = [intervals[0]];
    for (const [s,e] of intervals.slice(1)) {
        if (s <= res.at(-1)[1]) res.at(-1)[1] = Math.max(res.at(-1)[1], e);
        else res.push([s,e]);
    }
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/merge-intervals/",
  },

  // ===== SEARCHING =====
  {
    id: 16,
    title: "Binary Search",
    difficulty: "Easy",
    tags: ["Searching", "Arrays"],
    description: "Given a sorted array and a target, return the index if found, else -1.",
    input: "nums = [-1,0,3,5,9,12], target = 9",
    output: "4",
    hints: ["Use two pointers: low and high.", "Compare middle element with target."],
    solutions: {
      python: `def search(nums, target):
    lo, hi = 0, len(nums)-1
    while lo <= hi:
        mid = (lo+hi)//2
        if nums[mid] == target: return mid
        elif nums[mid] < target: lo = mid+1
        else: hi = mid-1
    return -1`,
      java: `public int search(int[] nums, int target) {
    int lo=0, hi=nums.length-1;
    while(lo<=hi) {
        int mid=lo+(hi-lo)/2;
        if(nums[mid]==target) return mid;
        else if(nums[mid]<target) lo=mid+1;
        else hi=mid-1;
    }
    return -1;
}`,
      cpp: `int search(vector<int>& nums, int target) {
    int lo=0, hi=nums.size()-1;
    while(lo<=hi) {
        int mid=lo+(hi-lo)/2;
        if(nums[mid]==target) return mid;
        else if(nums[mid]<target) lo=mid+1;
        else hi=mid-1;
    }
    return -1;
}`,
      javascript: `function search(nums, target) {
    let lo=0, hi=nums.length-1;
    while(lo<=hi) {
        const mid=Math.floor((lo+hi)/2);
        if(nums[mid]===target) return mid;
        else if(nums[mid]<target) lo=mid+1;
        else hi=mid-1;
    }
    return -1;
}`,
    },
    externalLink: "https://leetcode.com/problems/binary-search/",
  },
  {
    id: 17,
    title: "Search in Rotated Sorted Array",
    difficulty: "Medium",
    tags: ["Searching", "Arrays"],
    description: "Given a rotated sorted array and a target, return the index or -1. Must be O(log n).",
    input: "nums = [4,5,6,7,0,1,2], target = 0",
    output: "4",
    hints: ["Modified binary search.", "Determine which half is sorted, then decide which half to search."],
    solutions: {
      python: `def search(nums, target):
    lo, hi = 0, len(nums)-1
    while lo <= hi:
        mid = (lo+hi)//2
        if nums[mid] == target: return mid
        if nums[lo] <= nums[mid]:
            if nums[lo] <= target < nums[mid]: hi = mid-1
            else: lo = mid+1
        else:
            if nums[mid] < target <= nums[hi]: lo = mid+1
            else: hi = mid-1
    return -1`,
      java: `public int search(int[] nums, int target) {
    int lo=0, hi=nums.length-1;
    while(lo<=hi) {
        int mid=(lo+hi)/2;
        if(nums[mid]==target) return mid;
        if(nums[lo]<=nums[mid]) {
            if(nums[lo]<=target && target<nums[mid]) hi=mid-1;
            else lo=mid+1;
        } else {
            if(nums[mid]<target && target<=nums[hi]) lo=mid+1;
            else hi=mid-1;
        }
    }
    return -1;
}`,
      cpp: `int search(vector<int>& nums, int target) {
    int lo=0, hi=nums.size()-1;
    while(lo<=hi) {
        int mid=(lo+hi)/2;
        if(nums[mid]==target) return mid;
        if(nums[lo]<=nums[mid]) {
            if(nums[lo]<=target && target<nums[mid]) hi=mid-1;
            else lo=mid+1;
        } else {
            if(nums[mid]<target && target<=nums[hi]) lo=mid+1;
            else hi=mid-1;
        }
    }
    return -1;
}`,
      javascript: `function search(nums, target) {
    let lo=0, hi=nums.length-1;
    while(lo<=hi) {
        const mid=Math.floor((lo+hi)/2);
        if(nums[mid]===target) return mid;
        if(nums[lo]<=nums[mid]) {
            if(nums[lo]<=target && target<nums[mid]) hi=mid-1;
            else lo=mid+1;
        } else {
            if(nums[mid]<target && target<=nums[hi]) lo=mid+1;
            else hi=mid-1;
        }
    }
    return -1;
}`,
    },
    externalLink: "https://leetcode.com/problems/search-in-rotated-sorted-array/",
  },
  {
    id: 18,
    title: "Find First and Last Position",
    difficulty: "Medium",
    tags: ["Searching", "Arrays"],
    description: "Find the starting and ending position of a given target value in a sorted array. O(log n).",
    input: "nums = [5,7,7,8,8,10], target = 8",
    output: "[3,4]",
    hints: ["Use binary search twice.", "Once for the leftmost, once for the rightmost."],
    solutions: {
      python: `def searchRange(nums, target):
    def bisect(left):
        lo, hi = 0, len(nums)-1
        idx = -1
        while lo <= hi:
            mid = (lo+hi)//2
            if nums[mid] == target:
                idx = mid
                if left: hi = mid-1
                else: lo = mid+1
            elif nums[mid] < target: lo = mid+1
            else: hi = mid-1
        return idx
    return [bisect(True), bisect(False)]`,
      java: `public int[] searchRange(int[] nums, int target) {
    return new int[]{find(nums,target,true), find(nums,target,false)};
}
int find(int[] nums, int t, boolean left) {
    int lo=0, hi=nums.length-1, idx=-1;
    while(lo<=hi) {
        int mid=(lo+hi)/2;
        if(nums[mid]==t) { idx=mid; if(left) hi=mid-1; else lo=mid+1; }
        else if(nums[mid]<t) lo=mid+1; else hi=mid-1;
    }
    return idx;
}`,
      cpp: `vector<int> searchRange(vector<int>& nums, int target) {
    auto find = [&](bool left) {
        int lo=0, hi=nums.size()-1, idx=-1;
        while(lo<=hi) {
            int mid=(lo+hi)/2;
            if(nums[mid]==target) { idx=mid; left ? hi=mid-1 : lo=mid+1; }
            else if(nums[mid]<target) lo=mid+1; else hi=mid-1;
        }
        return idx;
    };
    return {find(true), find(false)};
}`,
      javascript: `function searchRange(nums, target) {
    const find = (left) => {
        let lo=0, hi=nums.length-1, idx=-1;
        while(lo<=hi) {
            const mid=Math.floor((lo+hi)/2);
            if(nums[mid]===target) { idx=mid; left ? hi=mid-1 : lo=mid+1; }
            else if(nums[mid]<target) lo=mid+1; else hi=mid-1;
        }
        return idx;
    };
    return [find(true), find(false)];
}`,
    },
    externalLink: "https://leetcode.com/problems/find-first-and-last-position-of-element-in-sorted-array/",
  },
  {
    id: 19,
    title: "Search a 2D Matrix",
    difficulty: "Medium",
    tags: ["Searching", "Arrays"],
    description: "Search for a target in an m x n matrix where each row is sorted and the first integer of each row is greater than the last of the previous row.",
    input: "matrix = [[1,3,5,7],[10,11,16,20],[23,30,34,60]], target = 3",
    output: "true",
    hints: ["Treat the matrix as a 1D sorted array.", "Use binary search with index mapping."],
    solutions: {
      python: `def searchMatrix(matrix, target):
    m, n = len(matrix), len(matrix[0])
    lo, hi = 0, m*n-1
    while lo <= hi:
        mid = (lo+hi)//2
        val = matrix[mid//n][mid%n]
        if val == target: return True
        elif val < target: lo = mid+1
        else: hi = mid-1
    return False`,
      java: `public boolean searchMatrix(int[][] matrix, int target) {
    int m=matrix.length, n=matrix[0].length;
    int lo=0, hi=m*n-1;
    while(lo<=hi) {
        int mid=(lo+hi)/2, val=matrix[mid/n][mid%n];
        if(val==target) return true;
        else if(val<target) lo=mid+1; else hi=mid-1;
    }
    return false;
}`,
      cpp: `bool searchMatrix(vector<vector<int>>& matrix, int target) {
    int m=matrix.size(), n=matrix[0].size();
    int lo=0, hi=m*n-1;
    while(lo<=hi) {
        int mid=(lo+hi)/2, val=matrix[mid/n][mid%n];
        if(val==target) return true;
        else if(val<target) lo=mid+1; else hi=mid-1;
    }
    return false;
}`,
      javascript: `function searchMatrix(matrix, target) {
    const m=matrix.length, n=matrix[0].length;
    let lo=0, hi=m*n-1;
    while(lo<=hi) {
        const mid=Math.floor((lo+hi)/2);
        const val=matrix[Math.floor(mid/n)][mid%n];
        if(val===target) return true;
        else if(val<target) lo=mid+1; else hi=mid-1;
    }
    return false;
}`,
    },
    externalLink: "https://leetcode.com/problems/search-a-2d-matrix/",
  },

  // ===== RECURSION =====
  {
    id: 20,
    title: "Fibonacci Number",
    difficulty: "Easy",
    tags: ["Recursion", "Dynamic Programming"],
    description: "The Fibonacci numbers form a sequence where each number is the sum of the two preceding ones. Given n, calculate F(n).",
    input: "n = 4",
    output: "3",
    hints: ["Base cases: F(0)=0, F(1)=1.", "Use memoization to avoid recomputation."],
    solutions: {
      python: `def fib(n):
    if n <= 1: return n
    a, b = 0, 1
    for _ in range(2, n+1):
        a, b = b, a+b
    return b`,
      java: `public int fib(int n) {
    if (n <= 1) return n;
    int a=0, b=1;
    for (int i=2; i<=n; i++) { int t=a+b; a=b; b=t; }
    return b;
}`,
      cpp: `int fib(int n) {
    if(n<=1) return n;
    int a=0, b=1;
    for(int i=2;i<=n;i++) { int t=a+b; a=b; b=t; }
    return b;
}`,
      javascript: `function fib(n) {
    if (n <= 1) return n;
    let a=0, b=1;
    for (let i=2; i<=n; i++) [a,b] = [b, a+b];
    return b;
}`,
    },
    externalLink: "https://leetcode.com/problems/fibonacci-number/",
  },
  {
    id: 21,
    title: "Power of Two",
    difficulty: "Easy",
    tags: ["Recursion", "Bit Manipulation"],
    description: "Given an integer n, return true if it is a power of two.",
    input: "n = 16",
    output: "true",
    hints: ["A power of two has exactly one bit set.", "Use n & (n-1) == 0."],
    solutions: {
      python: `def isPowerOfTwo(n):
    return n > 0 and (n & (n-1)) == 0`,
      java: `public boolean isPowerOfTwo(int n) {
    return n > 0 && (n & (n-1)) == 0;
}`,
      cpp: `bool isPowerOfTwo(int n) {
    return n > 0 && (n & (n-1)) == 0;
}`,
      javascript: `function isPowerOfTwo(n) {
    return n > 0 && (n & (n-1)) === 0;
}`,
    },
    externalLink: "https://leetcode.com/problems/power-of-two/",
  },
  {
    id: 22,
    title: "Subsets",
    difficulty: "Medium",
    tags: ["Recursion", "Backtracking"],
    description: "Given an integer array nums of unique elements, return all possible subsets (the power set).",
    input: "nums = [1,2,3]",
    output: "[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]",
    hints: ["Use backtracking.", "At each step, choose to include or exclude the current element."],
    solutions: {
      python: `def subsets(nums):
    res = []
    def bt(start, path):
        res.append(path[:])
        for i in range(start, len(nums)):
            path.append(nums[i])
            bt(i+1, path)
            path.pop()
    bt(0, [])
    return res`,
      java: `public List<List<Integer>> subsets(int[] nums) {
    List<List<Integer>> res = new ArrayList<>();
    bt(nums, 0, new ArrayList<>(), res);
    return res;
}
void bt(int[] nums, int s, List<Integer> path, List<List<Integer>> res) {
    res.add(new ArrayList<>(path));
    for (int i=s; i<nums.length; i++) {
        path.add(nums[i]); bt(nums, i+1, path, res); path.remove(path.size()-1);
    }
}`,
      cpp: `vector<vector<int>> subsets(vector<int>& nums) {
    vector<vector<int>> res;
    vector<int> path;
    function<void(int)> bt = [&](int s) {
        res.push_back(path);
        for(int i=s; i<nums.size(); i++) {
            path.push_back(nums[i]); bt(i+1); path.pop_back();
        }
    };
    bt(0);
    return res;
}`,
      javascript: `function subsets(nums) {
    const res = [];
    const bt = (start, path) => {
        res.push([...path]);
        for (let i=start; i<nums.length; i++) {
            path.push(nums[i]); bt(i+1, path); path.pop();
        }
    };
    bt(0, []);
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/subsets/",
  },
  {
    id: 23,
    title: "Permutations",
    difficulty: "Medium",
    tags: ["Recursion", "Backtracking"],
    description: "Given an array nums of distinct integers, return all the possible permutations.",
    input: "nums = [1,2,3]",
    output: "[[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]",
    hints: ["Use backtracking with a visited set.", "Swap elements to generate permutations in-place."],
    solutions: {
      python: `def permute(nums):
    res = []
    def bt(path, used):
        if len(path) == len(nums):
            res.append(path[:]); return
        for i in range(len(nums)):
            if i not in used:
                used.add(i); path.append(nums[i])
                bt(path, used)
                path.pop(); used.remove(i)
    bt([], set())
    return res`,
      java: `public List<List<Integer>> permute(int[] nums) {
    List<List<Integer>> res = new ArrayList<>();
    bt(nums, new ArrayList<>(), new boolean[nums.length], res);
    return res;
}
void bt(int[] nums, List<Integer> path, boolean[] used, List<List<Integer>> res) {
    if(path.size()==nums.length) { res.add(new ArrayList<>(path)); return; }
    for(int i=0;i<nums.length;i++) {
        if(!used[i]) { used[i]=true; path.add(nums[i]); bt(nums,path,used,res); path.remove(path.size()-1); used[i]=false; }
    }
}`,
      cpp: `vector<vector<int>> permute(vector<int>& nums) {
    vector<vector<int>> res;
    sort(nums.begin(), nums.end());
    do { res.push_back(nums); } while(next_permutation(nums.begin(), nums.end()));
    return res;
}`,
      javascript: `function permute(nums) {
    const res = [];
    const bt = (path, used) => {
        if(path.length===nums.length) { res.push([...path]); return; }
        for(let i=0;i<nums.length;i++) {
            if(!used.has(i)) { used.add(i); path.push(nums[i]); bt(path,used); path.pop(); used.delete(i); }
        }
    };
    bt([], new Set());
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/permutations/",
  },

  // ===== LINKED LIST =====
  {
    id: 24,
    title: "Reverse Linked List",
    difficulty: "Easy",
    tags: ["Linked List"],
    description: "Given the head of a singly linked list, reverse the list, and return the reversed list.",
    input: "head = [1,2,3,4,5]",
    output: "[5,4,3,2,1]",
    hints: ["Use three pointers: prev, curr, next.", "Iterate and reverse each link."],
    solutions: {
      python: `def reverseList(head):
    prev = None
    while head:
        nxt = head.next
        head.next = prev
        prev = head
        head = nxt
    return prev`,
      java: `public ListNode reverseList(ListNode head) {
    ListNode prev = null;
    while (head != null) {
        ListNode next = head.next;
        head.next = prev;
        prev = head;
        head = next;
    }
    return prev;
}`,
      cpp: `ListNode* reverseList(ListNode* head) {
    ListNode* prev = nullptr;
    while(head) {
        auto next = head->next;
        head->next = prev;
        prev = head;
        head = next;
    }
    return prev;
}`,
      javascript: `function reverseList(head) {
    let prev = null;
    while (head) {
        const next = head.next;
        head.next = prev;
        prev = head;
        head = next;
    }
    return prev;
}`,
    },
    externalLink: "https://leetcode.com/problems/reverse-linked-list/",
  },
  {
    id: 25,
    title: "Merge Two Sorted Lists",
    difficulty: "Easy",
    tags: ["Linked List"],
    description: "Merge two sorted linked lists and return it as a sorted list.",
    input: "l1 = [1,2,4], l2 = [1,3,4]",
    output: "[1,1,2,3,4,4]",
    hints: ["Use a dummy node.", "Compare heads and advance the smaller one."],
    solutions: {
      python: `def mergeTwoLists(l1, l2):
    dummy = cur = ListNode()
    while l1 and l2:
        if l1.val <= l2.val:
            cur.next = l1; l1 = l1.next
        else:
            cur.next = l2; l2 = l2.next
        cur = cur.next
    cur.next = l1 or l2
    return dummy.next`,
      java: `public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
    ListNode dummy = new ListNode(), cur = dummy;
    while (l1!=null && l2!=null) {
        if (l1.val<=l2.val) { cur.next=l1; l1=l1.next; }
        else { cur.next=l2; l2=l2.next; }
        cur=cur.next;
    }
    cur.next = l1!=null ? l1 : l2;
    return dummy.next;
}`,
      cpp: `ListNode* mergeTwoLists(ListNode* l1, ListNode* l2) {
    ListNode dummy, *cur = &dummy;
    while(l1 && l2) {
        if(l1->val <= l2->val) { cur->next=l1; l1=l1->next; }
        else { cur->next=l2; l2=l2->next; }
        cur=cur->next;
    }
    cur->next = l1 ? l1 : l2;
    return dummy.next;
}`,
      javascript: `function mergeTwoLists(l1, l2) {
    const dummy = { next: null }; let cur = dummy;
    while (l1 && l2) {
        if (l1.val <= l2.val) { cur.next=l1; l1=l1.next; }
        else { cur.next=l2; l2=l2.next; }
        cur = cur.next;
    }
    cur.next = l1 || l2;
    return dummy.next;
}`,
    },
    externalLink: "https://leetcode.com/problems/merge-two-sorted-lists/",
  },
  {
    id: 26,
    title: "Linked List Cycle",
    difficulty: "Easy",
    tags: ["Linked List", "Two Pointers"],
    description: "Given head, determine if the linked list has a cycle in it.",
    input: "head = [3,2,0,-4], pos = 1",
    output: "true",
    hints: ["Use Floyd's cycle detection (tortoise and hare).", "If fast meets slow, there's a cycle."],
    solutions: {
      python: `def hasCycle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast: return True
    return False`,
      java: `public boolean hasCycle(ListNode head) {
    ListNode slow=head, fast=head;
    while(fast!=null && fast.next!=null) {
        slow=slow.next; fast=fast.next.next;
        if(slow==fast) return true;
    }
    return false;
}`,
      cpp: `bool hasCycle(ListNode* head) {
    auto slow=head, fast=head;
    while(fast && fast->next) {
        slow=slow->next; fast=fast->next->next;
        if(slow==fast) return true;
    }
    return false;
}`,
      javascript: `function hasCycle(head) {
    let slow=head, fast=head;
    while(fast && fast.next) {
        slow=slow.next; fast=fast.next.next;
        if(slow===fast) return true;
    }
    return false;
}`,
    },
    externalLink: "https://leetcode.com/problems/linked-list-cycle/",
  },
  {
    id: 27,
    title: "Remove Nth Node From End",
    difficulty: "Medium",
    tags: ["Linked List", "Two Pointers"],
    description: "Remove the nth node from the end of the list and return its head.",
    input: "head = [1,2,3,4,5], n = 2",
    output: "[1,2,3,5]",
    hints: ["Use two pointers with a gap of n.", "When fast reaches end, slow is at the node before target."],
    solutions: {
      python: `def removeNthFromEnd(head, n):
    dummy = ListNode(0, head)
    slow = fast = dummy
    for _ in range(n+1): fast = fast.next
    while fast:
        slow = slow.next; fast = fast.next
    slow.next = slow.next.next
    return dummy.next`,
      java: `public ListNode removeNthFromEnd(ListNode head, int n) {
    ListNode dummy = new ListNode(0, head);
    ListNode slow=dummy, fast=dummy;
    for(int i=0;i<=n;i++) fast=fast.next;
    while(fast!=null) { slow=slow.next; fast=fast.next; }
    slow.next=slow.next.next;
    return dummy.next;
}`,
      cpp: `ListNode* removeNthFromEnd(ListNode* head, int n) {
    ListNode dummy(0, head);
    auto slow=&dummy, fast=&dummy;
    for(int i=0;i<=n;i++) fast=fast->next;
    while(fast) { slow=slow->next; fast=fast->next; }
    slow->next=slow->next->next;
    return dummy.next;
}`,
      javascript: `function removeNthFromEnd(head, n) {
    const dummy = {val:0, next:head};
    let slow=dummy, fast=dummy;
    for(let i=0;i<=n;i++) fast=fast.next;
    while(fast) { slow=slow.next; fast=fast.next; }
    slow.next=slow.next.next;
    return dummy.next;
}`,
    },
    externalLink: "https://leetcode.com/problems/remove-nth-node-from-end-of-list/",
  },

  // ===== STACK =====
  {
    id: 28,
    title: "Valid Parentheses",
    difficulty: "Easy",
    tags: ["Stack", "Strings"],
    description: "Given a string s containing just '(', ')', '{', '}', '[' and ']', determine if the input string is valid.",
    input: 's = "()[]{}"',
    output: "true",
    hints: ["Use a stack.", "Push opening brackets, pop and match on closing brackets."],
    solutions: {
      python: `def isValid(s):
    stack = []
    pairs = {')':'(', '}':'{', ']':'['}
    for c in s:
        if c in pairs:
            if not stack or stack[-1] != pairs[c]: return False
            stack.pop()
        else: stack.append(c)
    return not stack`,
      java: `public boolean isValid(String s) {
    Stack<Character> stack = new Stack<>();
    for (char c : s.toCharArray()) {
        if (c=='(') stack.push(')');
        else if (c=='{') stack.push('}');
        else if (c=='[') stack.push(']');
        else if (stack.isEmpty() || stack.pop()!=c) return false;
    }
    return stack.isEmpty();
}`,
      cpp: `bool isValid(string s) {
    stack<char> st;
    for(char c : s) {
        if(c=='(') st.push(')');
        else if(c=='{') st.push('}');
        else if(c=='[') st.push(']');
        else if(st.empty() || st.top()!=c) return false;
        else st.pop();
    }
    return st.empty();
}`,
      javascript: `function isValid(s) {
    const stack = [], map = {')':'(','}':'{',']':'['};
    for (const c of s) {
        if (map[c]) {
            if (stack.pop() !== map[c]) return false;
        } else stack.push(c);
    }
    return stack.length === 0;
}`,
    },
    externalLink: "https://leetcode.com/problems/valid-parentheses/",
  },
  {
    id: 29,
    title: "Min Stack",
    difficulty: "Medium",
    tags: ["Stack", "Design"],
    description: "Design a stack that supports push, pop, top, and retrieving the minimum element in constant time.",
    input: '["MinStack","push","push","push","getMin","pop","top","getMin"]',
    output: "[null,null,null,null,-3,null,0,-2]",
    hints: ["Use two stacks: one for values, one for minimums.", "On each push, push the current min to the min stack."],
    solutions: {
      python: `class MinStack:
    def __init__(self):
        self.stack = []
        self.min_stack = []
    def push(self, val):
        self.stack.append(val)
        self.min_stack.append(min(val, self.min_stack[-1] if self.min_stack else val))
    def pop(self):
        self.stack.pop()
        self.min_stack.pop()
    def top(self): return self.stack[-1]
    def getMin(self): return self.min_stack[-1]`,
      java: `class MinStack {
    Stack<Integer> stack = new Stack<>(), mins = new Stack<>();
    public void push(int val) {
        stack.push(val);
        mins.push(mins.isEmpty() ? val : Math.min(val, mins.peek()));
    }
    public void pop() { stack.pop(); mins.pop(); }
    public int top() { return stack.peek(); }
    public int getMin() { return mins.peek(); }
}`,
      cpp: `class MinStack {
    stack<int> s, mins;
public:
    void push(int val) {
        s.push(val);
        mins.push(mins.empty() ? val : min(val, mins.top()));
    }
    void pop() { s.pop(); mins.pop(); }
    int top() { return s.top(); }
    int getMin() { return mins.top(); }
};`,
      javascript: `class MinStack {
    constructor() { this.stack=[]; this.mins=[]; }
    push(val) { this.stack.push(val); this.mins.push(Math.min(val, this.mins.at(-1)??Infinity)); }
    pop() { this.stack.pop(); this.mins.pop(); }
    top() { return this.stack.at(-1); }
    getMin() { return this.mins.at(-1); }
}`,
    },
    externalLink: "https://leetcode.com/problems/min-stack/",
  },
  {
    id: 30,
    title: "Daily Temperatures",
    difficulty: "Medium",
    tags: ["Stack", "Arrays"],
    description: "Given temperatures, return an array where answer[i] is the number of days you have to wait for a warmer temperature.",
    input: "temperatures = [73,74,75,71,69,72,76,73]",
    output: "[1,1,4,2,1,1,0,0]",
    hints: ["Use a monotonic decreasing stack.", "Store indices in the stack."],
    solutions: {
      python: `def dailyTemperatures(temps):
    res = [0]*len(temps)
    stack = []
    for i, t in enumerate(temps):
        while stack and temps[stack[-1]] < t:
            j = stack.pop()
            res[j] = i - j
        stack.append(i)
    return res`,
      java: `public int[] dailyTemperatures(int[] temps) {
    int[] res = new int[temps.length];
    Stack<Integer> stack = new Stack<>();
    for(int i=0;i<temps.length;i++) {
        while(!stack.isEmpty() && temps[stack.peek()]<temps[i])
            { int j=stack.pop(); res[j]=i-j; }
        stack.push(i);
    }
    return res;
}`,
      cpp: `vector<int> dailyTemperatures(vector<int>& temps) {
    int n=temps.size();
    vector<int> res(n,0);
    stack<int> st;
    for(int i=0;i<n;i++) {
        while(!st.empty() && temps[st.top()]<temps[i])
            { res[st.top()]=i-st.top(); st.pop(); }
        st.push(i);
    }
    return res;
}`,
      javascript: `function dailyTemperatures(temps) {
    const res = Array(temps.length).fill(0), stack = [];
    for(let i=0;i<temps.length;i++) {
        while(stack.length && temps[stack.at(-1)]<temps[i]) {
            const j=stack.pop(); res[j]=i-j;
        }
        stack.push(i);
    }
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/daily-temperatures/",
  },

  // ===== QUEUE =====
  {
    id: 31,
    title: "Implement Queue using Stacks",
    difficulty: "Easy",
    tags: ["Queue", "Stack", "Design"],
    description: "Implement a FIFO queue using only two stacks.",
    input: '["MyQueue","push","push","peek","pop","empty"]',
    output: "[null,null,null,1,1,false]",
    hints: ["Use two stacks: input and output.", "Transfer from input to output when output is empty."],
    solutions: {
      python: `class MyQueue:
    def __init__(self):
        self.s1, self.s2 = [], []
    def push(self, x): self.s1.append(x)
    def pop(self):
        self._move()
        return self.s2.pop()
    def peek(self):
        self._move()
        return self.s2[-1]
    def empty(self): return not self.s1 and not self.s2
    def _move(self):
        if not self.s2:
            while self.s1: self.s2.append(self.s1.pop())`,
      java: `class MyQueue {
    Stack<Integer> s1=new Stack<>(), s2=new Stack<>();
    public void push(int x) { s1.push(x); }
    public int pop() { move(); return s2.pop(); }
    public int peek() { move(); return s2.peek(); }
    public boolean empty() { return s1.isEmpty()&&s2.isEmpty(); }
    void move() { if(s2.isEmpty()) while(!s1.isEmpty()) s2.push(s1.pop()); }
}`,
      cpp: `class MyQueue {
    stack<int> s1, s2;
    void move() { if(s2.empty()) while(!s1.empty()) { s2.push(s1.top()); s1.pop(); } }
public:
    void push(int x) { s1.push(x); }
    int pop() { move(); int v=s2.top(); s2.pop(); return v; }
    int peek() { move(); return s2.top(); }
    bool empty() { return s1.empty()&&s2.empty(); }
};`,
      javascript: `class MyQueue {
    constructor() { this.s1=[]; this.s2=[]; }
    push(x) { this.s1.push(x); }
    pop() { this._move(); return this.s2.pop(); }
    peek() { this._move(); return this.s2.at(-1); }
    empty() { return !this.s1.length && !this.s2.length; }
    _move() { if(!this.s2.length) while(this.s1.length) this.s2.push(this.s1.pop()); }
}`,
    },
    externalLink: "https://leetcode.com/problems/implement-queue-using-stacks/",
  },
  {
    id: 32,
    title: "Sliding Window Maximum",
    difficulty: "Hard",
    tags: ["Queue", "Sliding Window"],
    description: "Given an array nums and window size k, return the max in each sliding window.",
    input: "nums = [1,3,-1,-3,5,3,6,7], k = 3",
    output: "[3,3,5,5,6,7]",
    hints: ["Use a deque (double-ended queue).", "Keep the deque in decreasing order."],
    solutions: {
      python: `from collections import deque
def maxSlidingWindow(nums, k):
    dq = deque()
    res = []
    for i, n in enumerate(nums):
        while dq and dq[0] < i-k+1: dq.popleft()
        while dq and nums[dq[-1]] < n: dq.pop()
        dq.append(i)
        if i >= k-1: res.append(nums[dq[0]])
    return res`,
      java: `public int[] maxSlidingWindow(int[] nums, int k) {
    Deque<Integer> dq = new ArrayDeque<>();
    int[] res = new int[nums.length-k+1];
    for(int i=0;i<nums.length;i++) {
        while(!dq.isEmpty()&&dq.peekFirst()<i-k+1) dq.pollFirst();
        while(!dq.isEmpty()&&nums[dq.peekLast()]<nums[i]) dq.pollLast();
        dq.offerLast(i);
        if(i>=k-1) res[i-k+1]=nums[dq.peekFirst()];
    }
    return res;
}`,
      cpp: `vector<int> maxSlidingWindow(vector<int>& nums, int k) {
    deque<int> dq;
    vector<int> res;
    for(int i=0;i<nums.size();i++) {
        while(!dq.empty()&&dq.front()<i-k+1) dq.pop_front();
        while(!dq.empty()&&nums[dq.back()]<nums[i]) dq.pop_back();
        dq.push_back(i);
        if(i>=k-1) res.push_back(nums[dq.front()]);
    }
    return res;
}`,
      javascript: `function maxSlidingWindow(nums, k) {
    const dq=[], res=[];
    for(let i=0;i<nums.length;i++) {
        while(dq.length&&dq[0]<i-k+1) dq.shift();
        while(dq.length&&nums[dq.at(-1)]<nums[i]) dq.pop();
        dq.push(i);
        if(i>=k-1) res.push(nums[dq[0]]);
    }
    return res;
}`,
    },
    externalLink: "https://leetcode.com/problems/sliding-window-maximum/",
  },
  {
    id: 33,
    title: "Number of Recent Calls",
    difficulty: "Easy",
    tags: ["Queue", "Design"],
    description: "Implement RecentCounter which counts the number of recent requests within a 3000ms time frame.",
    input: '["RecentCounter","ping","ping","ping","ping"]',
    output: "[null,1,2,3,3]",
    hints: ["Use a queue.", "Remove entries older than t - 3000."],
    solutions: {
      python: `from collections import deque
class RecentCounter:
    def __init__(self): self.q = deque()
    def ping(self, t):
        self.q.append(t)
        while self.q[0] < t - 3000: self.q.popleft()
        return len(self.q)`,
      java: `class RecentCounter {
    Queue<Integer> q = new LinkedList<>();
    public int ping(int t) {
        q.add(t);
        while(q.peek() < t-3000) q.poll();
        return q.size();
    }
}`,
      cpp: `class RecentCounter {
    queue<int> q;
public:
    int ping(int t) {
        q.push(t);
        while(q.front() < t-3000) q.pop();
        return q.size();
    }
};`,
      javascript: `class RecentCounter {
    constructor() { this.q = []; }
    ping(t) {
        this.q.push(t);
        while(this.q[0] < t-3000) this.q.shift();
        return this.q.length;
    }
}`,
    },
    externalLink: "https://leetcode.com/problems/number-of-recent-calls/",
  },

  // ===== DYNAMIC PROGRAMMING (extra) =====
  {
    id: 34,
    title: "Climbing Stairs",
    difficulty: "Easy",
    tags: ["Dynamic Programming", "Recursion"],
    description: "You are climbing a staircase with n steps. Each time you can climb 1 or 2 steps. How many distinct ways can you climb to the top?",
    input: "n = 3",
    output: "3",
    hints: ["This is like Fibonacci.", "dp[i] = dp[i-1] + dp[i-2]."],
    solutions: {
      python: `def climbStairs(n):
    a, b = 1, 1
    for _ in range(n-1):
        a, b = b, a+b
    return b`,
      java: `public int climbStairs(int n) {
    int a=1, b=1;
    for(int i=1;i<n;i++) { int t=a+b; a=b; b=t; }
    return b;
}`,
      cpp: `int climbStairs(int n) {
    int a=1, b=1;
    for(int i=1;i<n;i++) { int t=a+b; a=b; b=t; }
    return b;
}`,
      javascript: `function climbStairs(n) {
    let a=1, b=1;
    for(let i=1;i<n;i++) [a,b]=[b,a+b];
    return b;
}`,
    },
    externalLink: "https://leetcode.com/problems/climbing-stairs/",
  },
  {
    id: 35,
    title: "Coin Change",
    difficulty: "Medium",
    tags: ["Dynamic Programming"],
    description: "Given coins and an amount, return the fewest number of coins needed. Return -1 if not possible.",
    input: "coins = [1,2,5], amount = 11",
    output: "3",
    hints: ["Use bottom-up DP.", "dp[i] = min(dp[i], dp[i - coin] + 1) for each coin."],
    solutions: {
      python: `def coinChange(coins, amount):
    dp = [float('inf')] * (amount+1)
    dp[0] = 0
    for i in range(1, amount+1):
        for c in coins:
            if c <= i: dp[i] = min(dp[i], dp[i-c]+1)
    return dp[amount] if dp[amount] != float('inf') else -1`,
      java: `public int coinChange(int[] coins, int amount) {
    int[] dp = new int[amount+1];
    Arrays.fill(dp, amount+1);
    dp[0]=0;
    for(int i=1;i<=amount;i++)
        for(int c:coins) if(c<=i) dp[i]=Math.min(dp[i],dp[i-c]+1);
    return dp[amount]>amount ? -1 : dp[amount];
}`,
      cpp: `int coinChange(vector<int>& coins, int amount) {
    vector<int> dp(amount+1, amount+1);
    dp[0]=0;
    for(int i=1;i<=amount;i++)
        for(int c:coins) if(c<=i) dp[i]=min(dp[i],dp[i-c]+1);
    return dp[amount]>amount ? -1 : dp[amount];
}`,
      javascript: `function coinChange(coins, amount) {
    const dp = Array(amount+1).fill(Infinity);
    dp[0]=0;
    for(let i=1;i<=amount;i++)
        for(const c of coins) if(c<=i) dp[i]=Math.min(dp[i],dp[i-c]+1);
    return dp[amount]===Infinity ? -1 : dp[amount];
}`,
    },
    externalLink: "https://leetcode.com/problems/coin-change/",
  },
  {
    id: 36,
    title: "Longest Increasing Subsequence",
    difficulty: "Medium",
    tags: ["Dynamic Programming", "Arrays"],
    description: "Given an integer array nums, return the length of the longest strictly increasing subsequence.",
    input: "nums = [10,9,2,5,3,7,101,18]",
    output: "4",
    hints: ["Use DP where dp[i] is the length of LIS ending at index i.", "Or use patience sorting with binary search for O(n log n)."],
    solutions: {
      python: `def lengthOfLIS(nums):
    dp = [1]*len(nums)
    for i in range(1, len(nums)):
        for j in range(i):
            if nums[j] < nums[i]:
                dp[i] = max(dp[i], dp[j]+1)
    return max(dp)`,
      java: `public int lengthOfLIS(int[] nums) {
    int[] dp = new int[nums.length];
    Arrays.fill(dp, 1);
    int res = 1;
    for(int i=1;i<nums.length;i++) {
        for(int j=0;j<i;j++)
            if(nums[j]<nums[i]) dp[i]=Math.max(dp[i],dp[j]+1);
        res=Math.max(res,dp[i]);
    }
    return res;
}`,
      cpp: `int lengthOfLIS(vector<int>& nums) {
    vector<int> dp(nums.size(), 1);
    int res=1;
    for(int i=1;i<nums.size();i++) {
        for(int j=0;j<i;j++)
            if(nums[j]<nums[i]) dp[i]=max(dp[i],dp[j]+1);
        res=max(res,dp[i]);
    }
    return res;
}`,
      javascript: `function lengthOfLIS(nums) {
    const dp = Array(nums.length).fill(1);
    for(let i=1;i<nums.length;i++)
        for(let j=0;j<i;j++)
            if(nums[j]<nums[i]) dp[i]=Math.max(dp[i],dp[j]+1);
    return Math.max(...dp);
}`,
    },
    externalLink: "https://leetcode.com/problems/longest-increasing-subsequence/",
  },
];

export const topics = [
  { id: "arrays", name: "Arrays", icon: "LayoutGrid", count: 6, color: "165 80% 40%" },
  { id: "strings", name: "Strings", icon: "Type", count: 5, color: "270 60% 55%" },
  { id: "sorting", name: "Sorting", icon: "ArrowUpDown", count: 4, color: "30 90% 55%" },
  { id: "searching", name: "Searching", icon: "Search", count: 4, color: "200 80% 50%" },
  { id: "recursion", name: "Recursion", icon: "Zap", count: 4, color: "0 70% 55%" },
  { id: "linked-list", name: "Linked List", icon: "Link", count: 4, color: "340 70% 55%" },
  { id: "stack", name: "Stack", icon: "Layers", count: 3, color: "50 80% 50%" },
  { id: "queue", name: "Queue", icon: "ListOrdered", count: 3, color: "180 60% 45%" },
  { id: "dynamic-programming", name: "Dynamic Programming", icon: "GitBranch", count: 3, color: "120 50% 45%" },
];
