import { useState } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { python } from "@codemirror/lang-python";
import { java } from "@codemirror/lang-java";
import { cpp } from "@codemirror/lang-cpp";
import { javascript } from "@codemirror/lang-javascript";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useTheme } from "@/hooks/useTheme";
import { Copy, Check } from "lucide-react";

type Lang = "python" | "java" | "cpp" | "javascript";

const langLabels: Record<Lang, string> = {
  python: "Python",
  java: "Java",
  cpp: "C++",
  javascript: "JavaScript",
};

const langExtensions: Record<Lang, () => ReturnType<typeof python>> = {
  python: () => python(),
  java: () => java(),
  cpp: () => cpp(),
  javascript: () => javascript(),
};

interface CodeBlockProps {
  solutions: Record<Lang, string>;
}

export function CodeBlock({ solutions }: CodeBlockProps) {
  const [lang, setLang] = useLocalStorage<Lang>("algo-lang", "python");
  const [copied, setCopied] = useState(false);
  const { theme } = useTheme();

  const handleCopy = () => {
    navigator.clipboard.writeText(solutions[lang]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-xl border border-border overflow-hidden bg-card">
      <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-muted/50">
        <div className="flex gap-1">
          {(Object.keys(langLabels) as Lang[]).map(l => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                lang === l
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              {langLabels[l]}
            </button>
          ))}
        </div>
        <button
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-all"
        >
          {copied ? <><Check className="w-3.5 h-3.5 text-primary" /> Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
        </button>
      </div>
      <CodeMirror
        value={solutions[lang]}
        extensions={[langExtensions[lang]()]}
        theme={theme === "dark" ? "dark" : "light"}
        editable={false}
        basicSetup={{ lineNumbers: true, foldGutter: false }}
        className="text-sm"
        style={{ maxHeight: "400px" }}
      />
    </div>
  );
}
