import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Bookmark, BookmarkCheck, Check, ExternalLink, Lightbulb, ChevronDown, ChevronUp } from "lucide-react";
import { problems } from "@/data/problems";
import { CodeBlock } from "@/components/CodeBlock";
import { useLocalStorage } from "@/hooks/useLocalStorage";

export default function ProblemDetailPage() {
  const { id } = useParams();
  const problem = problems.find(p => p.id === Number(id));
  const [showHints, setShowHints] = useState(false);
  const [showSolution, setShowSolution] = useState(false);
  const [bookmarks, setBookmarks] = useLocalStorage<number[]>("algo-bookmarks", []);
  const [solved, setSolved] = useLocalStorage<number[]>("algo-solved", []);

  if (!problem) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Problem not found</h2>
          <Link to="/practice" className="text-primary hover:underline">Back to Practice</Link>
        </div>
      </div>
    );
  }

  const isBookmarked = bookmarks.includes(problem.id);
  const isSolved = solved.includes(problem.id);

  const toggleBookmark = () => {
    setBookmarks(prev => prev.includes(problem.id) ? prev.filter(b => b !== problem.id) : [...prev, problem.id]);
  };

  const toggleSolved = () => {
    setSolved(prev => prev.includes(problem.id) ? prev.filter(s => s !== problem.id) : [...prev, problem.id]);
  };

  const diffBadge = problem.difficulty === "Easy" ? "algo-badge-easy" : problem.difficulty === "Medium" ? "algo-badge-medium" : "algo-badge-hard";

  return (
    <div className="min-h-screen p-6 lg:p-8 max-w-4xl">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <Link to="/practice" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Problems
        </Link>

        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold mb-2">{problem.title}</h1>
            <div className="flex items-center gap-2">
              <span className={diffBadge}>{problem.difficulty}</span>
              {problem.tags.map(tag => (
                <span key={tag} className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">{tag}</span>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={toggleBookmark} className="p-2 rounded-lg border border-border hover:bg-muted transition-colors">
              {isBookmarked ? <BookmarkCheck className="w-5 h-5 text-primary" /> : <Bookmark className="w-5 h-5 text-muted-foreground" />}
            </button>
            <button
              onClick={toggleSolved}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                isSolved ? "bg-primary text-primary-foreground" : "border border-border hover:bg-muted"
              }`}
            >
              <Check className="w-4 h-4" /> {isSolved ? "Solved" : "Mark Solved"}
            </button>
            <a
              href={problem.externalLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border border-border hover:bg-muted transition-colors"
            >
              <ExternalLink className="w-4 h-4" /> LeetCode
            </a>
          </div>
        </div>

        {/* Description */}
        <div className="algo-card p-6 mb-4">
          <h3 className="font-semibold mb-3">Description</h3>
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">{problem.description}</p>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-muted/50 rounded-lg p-3">
              <div className="text-xs font-medium text-muted-foreground mb-1">Input</div>
              <code className="text-sm font-mono">{problem.input}</code>
            </div>
            <div className="bg-muted/50 rounded-lg p-3">
              <div className="text-xs font-medium text-muted-foreground mb-1">Output</div>
              <code className="text-sm font-mono">{problem.output}</code>
            </div>
          </div>
        </div>

        {/* Hints */}
        <div className="algo-card p-4 mb-4">
          <button
            onClick={() => setShowHints(!showHints)}
            className="flex items-center justify-between w-full"
          >
            <div className="flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-medium" />
              <span className="font-medium text-sm">Hints ({problem.hints.length})</span>
            </div>
            {showHints ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          {showHints && (
            <div className="mt-3 space-y-2">
              {problem.hints.map((hint, i) => (
                <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <span className="text-medium font-semibold">💡</span>
                  <span>{hint}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Solution */}
        <div className="mb-4">
          <button
            onClick={() => setShowSolution(!showSolution)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium mb-3 transition-all"
            style={{ background: showSolution ? "hsl(var(--primary) / 0.15)" : "hsl(var(--muted))", color: showSolution ? "hsl(var(--primary))" : undefined }}
          >
            {showSolution ? "Hide Solution" : "Show Solution"}
          </button>
          {showSolution && <CodeBlock solutions={problem.solutions} />}
        </div>
      </motion.div>
    </div>
  );
}
