import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Code2, BookOpen, BarChart3, Sparkles, Zap, Target } from "lucide-react";
import { problems } from "@/data/problems";

const features = [
  { icon: BookOpen, title: "Learn DSA", desc: "Beginner-friendly explanations with real-world analogies", color: "165 80% 40%" },
  { icon: Code2, title: "Practice Problems", desc: "Curated problems with multi-language solutions", color: "270 60% 55%" },
  { icon: BarChart3, title: "Visualize Algorithms", desc: "See sorting algorithms come to life with animations", color: "30 90% 55%" },
];

const stats = [
  { value: `${problems.length}+`, label: "Problems", icon: Target },
  { value: "5", label: "Algorithms", icon: Zap },
  { value: "4", label: "Languages", icon: Code2 },
];

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden px-8 py-20 lg:py-28">
        <div className="absolute inset-0 opacity-30" style={{ background: "var(--gradient-hero)" }} />
        <div className="absolute top-20 right-20 w-72 h-72 rounded-full opacity-10 blur-3xl" style={{ background: "hsl(165, 80%, 45%)" }} />
        <div className="absolute bottom-10 left-10 w-56 h-56 rounded-full opacity-10 blur-3xl" style={{ background: "hsl(270, 60%, 55%)" }} />

        <div className="relative max-w-4xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/10 mb-8">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Interactive Learning Platform</span>
            </div>

            <h1 className="text-5xl lg:text-7xl font-black tracking-tight mb-6">
              Master{" "}
              <span className="algo-gradient-text">Algorithms</span>
              <br />
              Visually
            </h1>

            <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Learn data structures and algorithms through interactive visualizations,
              hands-on practice, and beginner-friendly explanations.
            </p>

            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Link
                to="/learn"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-semibold text-primary-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg"
                style={{ background: "var(--gradient-primary)" }}
              >
                Start Learning <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/visualizer"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-semibold border border-border bg-card text-foreground transition-all duration-300 hover:scale-105"
              >
                Try Visualizer <BarChart3 className="w-5 h-5" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="px-8 py-8">
        <div className="max-w-4xl mx-auto grid grid-cols-3 gap-4">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="algo-card p-6 text-center"
            >
              <stat.icon className="w-6 h-6 mx-auto mb-2 text-primary" />
              <div className="text-3xl font-bold">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="px-8 py-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Everything you need to <span className="algo-gradient-text">learn DSA</span>
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feat, i) => (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + i * 0.15 }}
                className="algo-card p-6 group"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                  style={{ background: `hsl(${feat.color} / 0.15)` }}
                >
                  <feat.icon className="w-6 h-6" style={{ color: `hsl(${feat.color})` }} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feat.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feat.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-8 py-8 border-t border-border">
        <div className="max-w-5xl mx-auto text-center text-sm text-muted-foreground">
          Built with ❤️ for aspiring developers · AlgoPlayground
        </div>
      </footer>
    </div>
  );
}
