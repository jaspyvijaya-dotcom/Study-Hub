import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { topics } from "@/data/problems";
import { learnContent } from "@/data/learnContent";
import {
  LayoutGrid, Type, ArrowUpDown, Search, Link as LinkIcon,
  Layers, ListOrdered, GitBranch, Zap, ChevronRight, Clock, BookOpen
} from "lucide-react";

const iconMap: Record<string, React.ElementType> = {
  LayoutGrid, Type, ArrowUpDown, Search, Link: LinkIcon,
  Layers, ListOrdered, GitBranch, Zap,
};

export default function LearnPage() {
  const [selectedTopic, setSelectedTopic] = useState("arrays");
  const content = learnContent[selectedTopic];

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold mb-2">Learn Data Structures & Algorithms</h1>
        <p className="text-muted-foreground mb-8">Master the fundamentals with clear explanations and examples</p>
      </motion.div>

      {/* Topic Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mb-10">
        {topics.map((topic, i) => {
          const Icon = iconMap[topic.icon] || LayoutGrid;
          const isActive = selectedTopic === topic.id;
          return (
            <motion.button
              key={topic.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              onClick={() => setSelectedTopic(topic.id)}
              className={`algo-card p-4 text-center transition-all ${isActive ? "ring-2 ring-primary algo-glow" : ""}`}
            >
              <div
                className="w-10 h-10 rounded-lg mx-auto mb-2 flex items-center justify-center"
                style={{ background: `hsl(${topic.color} / 0.15)` }}
              >
                <Icon className="w-5 h-5" style={{ color: `hsl(${topic.color})` }} />
              </div>
              <div className="text-sm font-medium">{topic.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{topic.count} problems</div>
            </motion.button>
          );
        })}
      </div>

      {/* Content */}
      {content ? (
        <motion.div
          key={selectedTopic}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl space-y-6"
        >
          <div className="algo-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-bold">{content.title}</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">{content.intro}</p>
          </div>

          <div className="algo-card p-6 border-l-4" style={{ borderLeftColor: "hsl(var(--primary))" }}>
            <h3 className="font-semibold mb-2">💡 Real-Life Analogy</h3>
            <p className="text-muted-foreground leading-relaxed">{content.analogy}</p>
          </div>

          <div className="algo-card p-6">
            <h3 className="font-semibold mb-4">Key Concepts</h3>
            <div className="space-y-3">
              {content.steps.map((step, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/15 text-primary flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <p className="text-sm text-muted-foreground">{step}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="algo-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Time & Space Complexity</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 pr-4 font-medium">Operation</th>
                    <th className="text-left py-2 pr-4 font-medium">Time</th>
                    <th className="text-left py-2 font-medium">Space</th>
                  </tr>
                </thead>
                <tbody>
                  {content.complexity.map(row => (
                    <tr key={row.op} className="border-b border-border/50">
                      <td className="py-2 pr-4 text-muted-foreground">{row.op}</td>
                      <td className="py-2 pr-4"><code className="text-primary font-mono text-xs bg-primary/10 px-2 py-0.5 rounded">{row.time}</code></td>
                      <td className="py-2"><code className="font-mono text-xs bg-muted px-2 py-0.5 rounded">{row.space}</code></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="algo-card p-6">
            <h3 className="font-semibold mb-4">Code Example</h3>
            <pre className="bg-muted/50 rounded-lg p-4 overflow-x-auto text-sm font-mono leading-relaxed">
              {content.codeExample}
            </pre>
          </div>

          <div className="algo-card p-6 text-center" style={{ background: "hsl(var(--primary) / 0.05)" }}>
            <h3 className="font-semibold mb-2">Ready to practice?</h3>
            <p className="text-sm text-muted-foreground mb-4">Apply what you've learned with curated {content.title.toLowerCase()} problems</p>
            <Link
              to="/practice"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-semibold text-primary-foreground"
              style={{ background: "var(--gradient-primary)" }}
            >
              Practice {content.title} Problems <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="algo-card p-12 text-center max-w-2xl">
          <div className="text-4xl mb-4">🚧</div>
          <h3 className="text-lg font-semibold mb-2">Coming Soon</h3>
          <p className="text-sm text-muted-foreground">
            Content for {topics.find(t => t.id === selectedTopic)?.name} is being prepared.
          </p>
        </motion.div>
      )}
    </div>
  );
}
