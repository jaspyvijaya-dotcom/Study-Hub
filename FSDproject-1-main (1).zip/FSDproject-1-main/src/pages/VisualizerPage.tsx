import { useState, useEffect, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw, Settings } from "lucide-react";

type Algorithm = "bubble" | "selection" | "insertion" | "merge" | "quick";

interface Bar {
  value: number;
  state: "default" | "comparing" | "swapping" | "sorted" | "pivot";
}

const algorithmInfo: Record<Algorithm, { name: string; time: string; space: string; desc: string }> = {
  bubble: { name: "Bubble Sort", time: "O(n²)", space: "O(1)", desc: "Repeatedly swaps adjacent elements if they are in the wrong order" },
  selection: { name: "Selection Sort", time: "O(n²)", space: "O(1)", desc: "Finds the minimum element and places it at the beginning" },
  insertion: { name: "Insertion Sort", time: "O(n²)", space: "O(1)", desc: "Builds sorted array one element at a time by inserting into correct position" },
  merge: { name: "Merge Sort", time: "O(n log n)", space: "O(n)", desc: "Divides array in half, sorts each half, then merges them" },
  quick: { name: "Quick Sort", time: "O(n log n)", space: "O(log n)", desc: "Picks a pivot, partitions array around it, then sorts partitions" },
};

function generateArray(size: number): Bar[] {
  return Array.from({ length: size }, () => ({
    value: Math.floor(Math.random() * 90) + 10,
    state: "default" as const,
  }));
}

export default function VisualizerPage() {
  const [algorithm, setAlgorithm] = useState<Algorithm>("bubble");
  const [bars, setBars] = useState<Bar[]>(generateArray(30));
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState(50);
  const [size, setSize] = useState(30);
  const stopRef = useRef(false);
  const [comparisons, setComparisons] = useState(0);
  const [swaps, setSwaps] = useState(0);

  const reset = useCallback(() => {
    stopRef.current = true;
    setIsRunning(false);
    setBars(generateArray(size));
    setComparisons(0);
    setSwaps(0);
  }, [size]);

  useEffect(() => { reset(); }, [size, reset]);

  const delay = () => new Promise(r => setTimeout(r, Math.max(5, 200 - speed * 2)));

  const updateBars = (newBars: Bar[]) => setBars([...newBars]);

  const bubbleSort = async (arr: Bar[]) => {
    let c = 0, s = 0;
    for (let i = 0; i < arr.length && !stopRef.current; i++) {
      for (let j = 0; j < arr.length - i - 1 && !stopRef.current; j++) {
        arr[j].state = "comparing";
        arr[j + 1].state = "comparing";
        updateBars(arr);
        c++; setComparisons(c);
        await delay();
        if (arr[j].value > arr[j + 1].value) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          arr[j].state = "swapping";
          arr[j + 1].state = "swapping";
          s++; setSwaps(s);
          updateBars(arr);
          await delay();
        }
        arr[j].state = "default";
        arr[j + 1].state = "default";
      }
      arr[arr.length - 1 - i].state = "sorted";
      updateBars(arr);
    }
  };

  const selectionSort = async (arr: Bar[]) => {
    let c = 0, s = 0;
    for (let i = 0; i < arr.length && !stopRef.current; i++) {
      let minIdx = i;
      arr[i].state = "pivot";
      updateBars(arr);
      for (let j = i + 1; j < arr.length && !stopRef.current; j++) {
        arr[j].state = "comparing";
        updateBars(arr);
        c++; setComparisons(c);
        await delay();
        if (arr[j].value < arr[minIdx].value) minIdx = j;
        arr[j].state = "default";
      }
      if (minIdx !== i) {
        [arr[i], arr[minIdx]] = [arr[minIdx], arr[i]];
        s++; setSwaps(s);
      }
      arr[i].state = "sorted";
      updateBars(arr);
    }
  };

  const insertionSort = async (arr: Bar[]) => {
    let c = 0, s = 0;
    arr[0].state = "sorted";
    updateBars(arr);
    for (let i = 1; i < arr.length && !stopRef.current; i++) {
      const key = arr[i];
      key.state = "comparing";
      updateBars(arr);
      await delay();
      let j = i - 1;
      while (j >= 0 && arr[j].value > key.value && !stopRef.current) {
        c++; setComparisons(c);
        arr[j + 1] = arr[j];
        arr[j].state = "swapping";
        s++; setSwaps(s);
        updateBars(arr);
        await delay();
        arr[j].state = "sorted";
        j--;
      }
      arr[j + 1] = key;
      arr[j + 1].state = "sorted";
      updateBars(arr);
    }
  };

  const mergeSort = async (arr: Bar[], l: number, r: number) => {
    if (l >= r || stopRef.current) return;
    const mid = Math.floor((l + r) / 2);
    await mergeSort(arr, l, mid);
    await mergeSort(arr, mid + 1, r);
    await merge(arr, l, mid, r);
  };

  const merge = async (arr: Bar[], l: number, mid: number, r: number) => {
    const left = arr.slice(l, mid + 1).map(b => ({ ...b }));
    const right = arr.slice(mid + 1, r + 1).map(b => ({ ...b }));
    let i = 0, j = 0, k = l;
    while (i < left.length && j < right.length && !stopRef.current) {
      setComparisons(c => c + 1);
      arr[k].state = "comparing";
      updateBars(arr);
      await delay();
      if (left[i].value <= right[j].value) {
        arr[k] = { ...left[i], state: "swapping" };
        i++;
      } else {
        arr[k] = { ...right[j], state: "swapping" };
        j++;
      }
      setSwaps(s => s + 1);
      updateBars(arr);
      await delay();
      arr[k].state = k <= mid ? "sorted" : "default";
      k++;
    }
    while (i < left.length && !stopRef.current) {
      arr[k] = { ...left[i], state: "sorted" };
      updateBars(arr);
      await delay();
      i++; k++;
    }
    while (j < right.length && !stopRef.current) {
      arr[k] = { ...right[j], state: "sorted" };
      updateBars(arr);
      await delay();
      j++; k++;
    }
  };

  const quickSort = async (arr: Bar[], low: number, high: number) => {
    if (low >= high || stopRef.current) return;
    const pi = await partition(arr, low, high);
    await quickSort(arr, low, pi - 1);
    await quickSort(arr, pi + 1, high);
  };

  const partition = async (arr: Bar[], low: number, high: number) => {
    const pivot = arr[high];
    pivot.state = "pivot";
    updateBars(arr);
    let i = low - 1;
    for (let j = low; j < high && !stopRef.current; j++) {
      arr[j].state = "comparing";
      setComparisons(c => c + 1);
      updateBars(arr);
      await delay();
      if (arr[j].value < pivot.value) {
        i++;
        [arr[i], arr[j]] = [arr[j], arr[i]];
        arr[i].state = "swapping";
        setSwaps(s => s + 1);
        updateBars(arr);
        await delay();
        arr[i].state = "default";
      }
      arr[j].state = "default";
    }
    [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
    arr[i + 1].state = "sorted";
    updateBars(arr);
    return i + 1;
  };

  const start = async () => {
    stopRef.current = false;
    setIsRunning(true);
    setComparisons(0);
    setSwaps(0);
    const arr: Bar[] = [...bars].map(b => ({ ...b, state: "default" }));
    setBars(arr);

    switch (algorithm) {
      case "bubble": await bubbleSort(arr); break;
      case "selection": await selectionSort(arr); break;
      case "insertion": await insertionSort(arr); break;
      case "merge": await mergeSort(arr, 0, arr.length - 1); break;
      case "quick": await quickSort(arr, 0, arr.length - 1); break;
    }

    if (!stopRef.current) {
      arr.forEach(b => (b.state = "sorted"));
      updateBars(arr);
    }
    setIsRunning(false);
  };

  const barColor = (state: Bar["state"]) => {
    switch (state) {
      case "comparing": return "hsl(var(--medium))";
      case "swapping": return "hsl(var(--hard))";
      case "sorted": return "hsl(var(--primary))";
      case "pivot": return "hsl(var(--accent))";
      default: return "hsl(var(--muted-foreground) / 0.4)";
    }
  };

  const info = algorithmInfo[algorithm];

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold mb-2">Algorithm Visualizer</h1>
        <p className="text-muted-foreground mb-6">Watch sorting algorithms in action</p>
      </motion.div>

      {/* Controls */}
      <div className="algo-card p-4 mb-6">
        <div className="flex flex-wrap items-center gap-4">
          {/* Algorithm selector */}
          <div className="flex gap-1">
            {(Object.keys(algorithmInfo) as Algorithm[]).map(algo => (
              <button
                key={algo}
                onClick={() => { if (!isRunning) setAlgorithm(algo); }}
                disabled={isRunning}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                  algorithm === algo
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                } disabled:opacity-50`}
              >
                {algorithmInfo[algo].name}
              </button>
            ))}
          </div>

          <div className="h-8 w-px bg-border" />

          {/* Speed */}
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Speed</span>
            <input
              type="range"
              min="1"
              max="100"
              value={speed}
              onChange={e => setSpeed(Number(e.target.value))}
              className="w-24 accent-primary"
            />
          </div>

          {/* Size */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Size</span>
            <input
              type="range"
              min="10"
              max="80"
              value={size}
              onChange={e => { if (!isRunning) setSize(Number(e.target.value)); }}
              disabled={isRunning}
              className="w-24 accent-primary"
            />
            <span className="text-xs text-muted-foreground w-6">{size}</span>
          </div>

          <div className="h-8 w-px bg-border" />

          {/* Action buttons */}
          <div className="flex gap-2">
            <button
              onClick={isRunning ? () => { stopRef.current = true; setIsRunning(false); } : start}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-primary-foreground transition-all"
              style={{ background: isRunning ? "hsl(var(--hard))" : "var(--gradient-primary)" }}
            >
              {isRunning ? <><Pause className="w-4 h-4" /> Stop</> : <><Play className="w-4 h-4" /> Start</>}
            </button>
            <button
              onClick={reset}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border border-border hover:bg-muted transition-colors"
            >
              <RotateCcw className="w-4 h-4" /> Reset
            </button>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="algo-card p-4 mb-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h3 className="font-semibold">{info.name}</h3>
            <p className="text-xs text-muted-foreground mt-1">{info.desc}</p>
          </div>
          <div className="flex gap-4 text-sm">
            <div><span className="text-muted-foreground">Time: </span><code className="text-primary font-mono bg-primary/10 px-2 py-0.5 rounded text-xs">{info.time}</code></div>
            <div><span className="text-muted-foreground">Space: </span><code className="font-mono bg-muted px-2 py-0.5 rounded text-xs">{info.space}</code></div>
            <div><span className="text-muted-foreground">Comparisons: </span><span className="font-semibold">{comparisons}</span></div>
            <div><span className="text-muted-foreground">Swaps: </span><span className="font-semibold">{swaps}</span></div>
          </div>
        </div>
      </div>

      {/* Bars */}
      <div className="algo-card p-6">
        <div className="flex items-end justify-center gap-[1px]" style={{ height: 350 }}>
          {bars.map((bar, i) => (
            <div
              key={i}
              className="rounded-t-sm transition-all duration-100"
              style={{
                height: `${bar.value}%`,
                width: `${Math.max(100 / bars.length - 1, 2)}%`,
                background: barColor(bar.state),
                minWidth: 2,
              }}
            />
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-6 mt-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm" style={{ background: "hsl(var(--muted-foreground) / 0.4)" }} /> Default</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm" style={{ background: "hsl(var(--medium))" }} /> Comparing</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm" style={{ background: "hsl(var(--hard))" }} /> Swapping</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm" style={{ background: "hsl(var(--primary))" }} /> Sorted</div>
          <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm" style={{ background: "hsl(var(--accent))" }} /> Pivot</div>
        </div>
      </div>
    </div>
  );
}
