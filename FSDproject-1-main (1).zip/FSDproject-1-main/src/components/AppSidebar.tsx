import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, BookOpen, Code2, BarChart3, ChevronLeft, ChevronRight,
  Sun, Moon, Sparkles, Menu, X
} from "lucide-react";
import { useTheme } from "@/hooks/useTheme";

const navItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/learn", label: "Learn", icon: BookOpen },
  { path: "/practice", label: "Practice", icon: Code2 },
  { path: "/visualizer", label: "Visualizer", icon: BarChart3 },
];

export function AppSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  const sidebarContent = (isMobile: boolean) => (
    <>
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-border/30">
        <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
             style={{ background: "var(--gradient-primary)" }}>
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <AnimatePresence>
          {(!collapsed || isMobile) && (
            <motion.span
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              className="font-bold text-lg tracking-tight overflow-hidden whitespace-nowrap"
              style={{ color: "hsl(var(--sidebar-fg))" }}
            >
              AlgoPlayground
            </motion.span>
          )}
        </AnimatePresence>
        {isMobile && (
          <button onClick={() => setMobileOpen(false)} className="ml-auto p-1" style={{ color: "hsl(var(--sidebar-fg))" }}>
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 py-4 px-2 space-y-1">
        {navItems.map(item => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => isMobile && setMobileOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative ${
                (collapsed && !isMobile) ? "justify-center" : ""
              }`}
              style={{
                background: isActive ? "hsl(var(--sidebar-active) / 0.15)" : "transparent",
                color: isActive ? "hsl(var(--sidebar-active))" : "hsl(var(--sidebar-fg))",
              }}
              onMouseEnter={e => {
                if (!isActive) e.currentTarget.style.background = "hsl(var(--sidebar-hover))";
              }}
              onMouseLeave={e => {
                if (!isActive) e.currentTarget.style.background = "transparent";
              }}
            >
              {isActive && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-r-full"
                  style={{ background: "hsl(var(--sidebar-active))" }}
                />
              )}
              <item.icon className="w-5 h-5 shrink-0" />
              <AnimatePresence>
                {(!collapsed || isMobile) && (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-sm font-medium"
                  >
                    {item.label}
                  </motion.span>
                )}
              </AnimatePresence>
            </Link>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="p-2 space-y-1 border-t border-border/30">
        {/* Theme toggle as a switch-style button */}
        <button
          onClick={toggleTheme}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg w-full transition-all duration-200"
          style={{ color: "hsl(var(--sidebar-fg))" }}
          onMouseEnter={e => { e.currentTarget.style.background = "hsl(var(--sidebar-hover))"; }}
          onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
        >
          <div className="relative w-10 h-5 rounded-full shrink-0" style={{ background: theme === "dark" ? "hsl(var(--sidebar-active) / 0.3)" : "hsl(var(--sidebar-fg) / 0.2)" }}>
            <motion.div
              className="absolute top-0.5 w-4 h-4 rounded-full flex items-center justify-center"
              animate={{ left: theme === "dark" ? 2 : 22 }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
              style={{ background: "hsl(var(--sidebar-active))" }}
            >
              {theme === "dark" ? <Moon className="w-2.5 h-2.5 text-white" /> : <Sun className="w-2.5 h-2.5 text-white" />}
            </motion.div>
          </div>
          <AnimatePresence>
            {(!collapsed || isMobile) && (
              <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-sm font-medium">
                {theme === "dark" ? "Dark Mode" : "Light Mode"}
              </motion.span>
            )}
          </AnimatePresence>
        </button>

        {!isMobile && (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg w-full transition-all duration-200"
            style={{ color: "hsl(var(--sidebar-fg))" }}
            onMouseEnter={e => { e.currentTarget.style.background = "hsl(var(--sidebar-hover))"; }}
            onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
          >
            {collapsed ? <ChevronRight className="w-5 h-5 shrink-0" /> : <ChevronLeft className="w-5 h-5 shrink-0" />}
            <AnimatePresence>
              {!collapsed && (
                <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-sm font-medium">
                  Collapse
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        )}
      </div>
    </>
  );

  return (
    <>
      {/* Mobile hamburger */}
      <button
        onClick={() => setMobileOpen(true)}
        className="fixed top-4 left-4 z-50 p-2 rounded-lg bg-card border border-border lg:hidden"
        style={{ boxShadow: "var(--shadow-md)" }}
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50 lg:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed left-0 top-0 h-screen w-[260px] z-50 flex flex-col border-r border-border lg:hidden"
              style={{ background: "hsl(var(--sidebar-bg))" }}
            >
              {sidebarContent(true)}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Desktop sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 68 : 260 }}
        transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
        className="fixed left-0 top-0 h-screen z-40 flex-col border-r border-border hidden lg:flex"
        style={{ background: "hsl(var(--sidebar-bg))" }}
      >
        {sidebarContent(false)}
      </motion.aside>
    </>
  );
}
