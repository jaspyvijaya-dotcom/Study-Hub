export interface TopicContent {
  title: string;
  intro: string;
  analogy: string;
  steps: string[];
  complexity: { op: string; time: string; space: string }[];
  codeExample: string;
}

export const learnContent: Record<string, TopicContent> = {
  arrays: {
    title: "Arrays",
    intro: "An array is a collection of elements stored at contiguous memory locations. Think of it like a row of lockers in a school — each locker has a number (index) and holds one item (value).",
    analogy: "🏫 Imagine a bookshelf where each slot is numbered. You can directly go to slot #5 and grab the book there — that's O(1) access! But if you want to insert a book in the middle, you have to shift everything after it — that's O(n).",
    steps: [
      "Arrays store elements in contiguous memory",
      "Each element is accessed by its index (0-based)",
      "Random access is O(1) — instant lookup by index",
      "Insertion/deletion may require shifting elements",
      "Arrays have fixed size in most languages (dynamic arrays like ArrayList/vector resize automatically)",
    ],
    complexity: [
      { op: "Access by index", time: "O(1)", space: "O(1)" },
      { op: "Search (unsorted)", time: "O(n)", space: "O(1)" },
      { op: "Search (sorted)", time: "O(log n)", space: "O(1)" },
      { op: "Insert at end", time: "O(1) amortized", space: "O(1)" },
      { op: "Insert at beginning", time: "O(n)", space: "O(1)" },
      { op: "Delete", time: "O(n)", space: "O(1)" },
    ],
    codeExample: `# Python Array Example
arr = [10, 20, 30, 40, 50]

# Access element by index
print(arr[2])  # 30

# Append element
arr.append(60)  # [10, 20, 30, 40, 50, 60]

# Insert at index
arr.insert(1, 15)  # [10, 15, 20, 30, 40, 50, 60]

# Remove element
arr.remove(30)  # [10, 15, 20, 40, 50, 60]

# Traverse
for i, val in enumerate(arr):
    print(f"Index {i}: {val}")`,
  },

  strings: {
    title: "Strings",
    intro: "A string is a sequence of characters. In most languages, strings are immutable — once created, they cannot be changed. Any 'modification' actually creates a new string.",
    analogy: "📿 Think of a string like a necklace of beads. Each bead is a character. You can look at any bead by its position, but to change the necklace, you need to take it apart and reassemble it. That's why string operations can be expensive!",
    steps: [
      "Strings are arrays of characters under the hood",
      "In Python and Java, strings are immutable — modifications create new strings",
      "Common operations: slicing, concatenation, searching, replacing",
      "String comparison is done character by character — O(n)",
      "StringBuilder/StringBuffer in Java avoids repeated allocation during concatenation",
      "Two-pointer and sliding window are powerful techniques for string problems",
    ],
    complexity: [
      { op: "Access character", time: "O(1)", space: "O(1)" },
      { op: "Concatenation", time: "O(n + m)", space: "O(n + m)" },
      { op: "Substring search", time: "O(n × m)", space: "O(1)" },
      { op: "KMP search", time: "O(n + m)", space: "O(m)" },
      { op: "Reverse", time: "O(n)", space: "O(n)" },
      { op: "Compare", time: "O(n)", space: "O(1)" },
    ],
    codeExample: `# Python String Examples
s = "hello world"

# Access character
print(s[4])  # 'o'

# Slicing
print(s[0:5])  # 'hello'

# Reverse a string
print(s[::-1])  # 'dlrow olleh'

# Check palindrome
def is_palindrome(s):
    s = s.lower().replace(" ", "")
    return s == s[::-1]

print(is_palindrome("racecar"))  # True

# Count character frequency
from collections import Counter
freq = Counter(s)
print(freq)  # Counter({'l': 3, 'o': 2, ...})

# Two-pointer: check if valid palindrome
def valid_palindrome(s):
    left, right = 0, len(s) - 1
    while left < right:
        if s[left] != s[right]:
            return False
        left += 1
        right -= 1
    return True`,
  },

  sorting: {
    title: "Sorting",
    intro: "Sorting is the process of arranging elements in a specific order (ascending or descending). It's one of the most fundamental operations in computer science and a building block for many algorithms.",
    analogy: "🃏 Imagine sorting a hand of playing cards. You might pick up one card at a time and place it in the right position (Insertion Sort), or repeatedly find the smallest card and move it to the front (Selection Sort). Each strategy has trade-offs!",
    steps: [
      "Bubble Sort: repeatedly swap adjacent elements if they're in wrong order — simple but slow",
      "Selection Sort: find the minimum element and place it at the correct position",
      "Insertion Sort: build sorted array one element at a time — great for nearly-sorted data",
      "Merge Sort: divide array in half, sort each half, merge — guaranteed O(n log n)",
      "Quick Sort: pick a pivot, partition around it, recurse — fastest in practice on average",
      "Stable sorts preserve relative order of equal elements (Merge Sort is stable, Quick Sort is not)",
    ],
    complexity: [
      { op: "Bubble Sort", time: "O(n²)", space: "O(1)" },
      { op: "Selection Sort", time: "O(n²)", space: "O(1)" },
      { op: "Insertion Sort", time: "O(n²) / O(n) best", space: "O(1)" },
      { op: "Merge Sort", time: "O(n log n)", space: "O(n)" },
      { op: "Quick Sort", time: "O(n log n) avg", space: "O(log n)" },
      { op: "Heap Sort", time: "O(n log n)", space: "O(1)" },
    ],
    codeExample: `# Sorting Algorithms in Python

# Bubble Sort
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

# Merge Sort
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i]); i += 1
        else:
            result.append(right[j]); j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

# Quick Sort
def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    mid = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + mid + quick_sort(right)`,
  },

  searching: {
    title: "Searching",
    intro: "Searching algorithms are designed to find an element in a data structure. The two fundamental approaches are Linear Search (check every element) and Binary Search (divide and conquer on sorted data).",
    analogy: "📖 Linear Search is like reading a book page by page to find a word. Binary Search is like looking up a word in a dictionary — you open to the middle, decide if your word comes before or after, and repeat. The dictionary approach is exponentially faster!",
    steps: [
      "Linear Search: scan every element one by one — works on any data, O(n)",
      "Binary Search: requires sorted data, eliminates half the search space each step — O(log n)",
      "Binary Search has many variations: lower bound, upper bound, search in rotated array",
      "Two pointers technique is often used alongside searching for optimization",
      "Hash-based search (hash tables) gives O(1) average lookup but uses extra space",
      "Binary Search on answer: use binary search to find optimal values in optimization problems",
    ],
    complexity: [
      { op: "Linear Search", time: "O(n)", space: "O(1)" },
      { op: "Binary Search", time: "O(log n)", space: "O(1)" },
      { op: "Hash Table Lookup", time: "O(1) avg", space: "O(n)" },
      { op: "Binary Search (recursive)", time: "O(log n)", space: "O(log n)" },
      { op: "Ternary Search", time: "O(log₃ n)", space: "O(1)" },
      { op: "Interpolation Search", time: "O(log log n) avg", space: "O(1)" },
    ],
    codeExample: `# Searching Algorithms in Python

# Linear Search
def linear_search(arr, target):
    for i, val in enumerate(arr):
        if val == target:
            return i
    return -1

# Binary Search (Iterative)
def binary_search(arr, target):
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1

# Lower Bound (first element >= target)
def lower_bound(arr, target):
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] < target:
            lo = mid + 1
        else:
            hi = mid
    return lo

# Binary Search on Rotated Sorted Array
def search_rotated(nums, target):
    lo, hi = 0, len(nums) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if nums[mid] == target:
            return mid
        if nums[lo] <= nums[mid]:
            if nums[lo] <= target < nums[mid]:
                hi = mid - 1
            else:
                lo = mid + 1
        else:
            if nums[mid] < target <= nums[hi]:
                lo = mid + 1
            else:
                hi = mid - 1
    return -1`,
  },

  "linked-list": {
    title: "Linked List",
    intro: "A linked list is a linear data structure where each element (node) contains data and a reference (pointer) to the next node. Unlike arrays, elements are NOT stored in contiguous memory — they're scattered and connected through pointers.",
    analogy: "🚂 Think of a train. Each car (node) holds passengers (data) and is connected to the next car by a coupling (pointer). To get to car #5, you must walk through cars 1, 2, 3, and 4 — no skipping! But adding/removing a car in the middle is easy: just disconnect and reconnect the couplings.",
    steps: [
      "Each node stores data + a pointer to the next node",
      "Singly linked: each node points to next only. Doubly linked: points to next AND previous",
      "No random access — must traverse from head to reach a position: O(n)",
      "Insertion/deletion at known position is O(1) — just rearrange pointers",
      "Uses more memory than arrays due to pointer storage",
      "Common techniques: dummy head node, fast/slow pointers, reversing in-place",
    ],
    complexity: [
      { op: "Access by index", time: "O(n)", space: "O(1)" },
      { op: "Search", time: "O(n)", space: "O(1)" },
      { op: "Insert at head", time: "O(1)", space: "O(1)" },
      { op: "Insert at tail", time: "O(n) / O(1)*", space: "O(1)" },
      { op: "Delete node (given ref)", time: "O(1)", space: "O(1)" },
      { op: "Reverse list", time: "O(n)", space: "O(1)" },
    ],
    codeExample: `# Linked List in Python

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

# Create: 1 -> 2 -> 3 -> 4
head = ListNode(1, ListNode(2, ListNode(3, ListNode(4))))

# Traverse and print
def print_list(head):
    curr = head
    while curr:
        print(curr.val, end=" -> ")
        curr = curr.next
    print("None")

# Reverse a linked list (iterative)
def reverse_list(head):
    prev, curr = None, head
    while curr:
        nxt = curr.next
        curr.next = prev
        prev = curr
        curr = nxt
    return prev

# Detect cycle (Floyd's algorithm)
def has_cycle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            return True
    return False

# Find middle node
def find_middle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    return slow`,
  },

  stack: {
    title: "Stack",
    intro: "A stack is a Last-In-First-Out (LIFO) data structure. The last element added is the first one removed — like a stack of plates. You can only add (push) or remove (pop) from the top.",
    analogy: "🍽️ Imagine a stack of plates in a cafeteria. You always take the TOP plate and add new plates on TOP. You can't pull a plate from the middle without removing everything above it. That's LIFO — Last In, First Out!",
    steps: [
      "Push: add element to the top — O(1)",
      "Pop: remove and return the top element — O(1)",
      "Peek/Top: view the top element without removing — O(1)",
      "Used for: function call management, undo operations, expression evaluation",
      "Can be implemented using arrays or linked lists",
      "Monotonic stack: powerful technique for 'next greater element' style problems",
    ],
    complexity: [
      { op: "Push", time: "O(1)", space: "O(1)" },
      { op: "Pop", time: "O(1)", space: "O(1)" },
      { op: "Peek / Top", time: "O(1)", space: "O(1)" },
      { op: "Search", time: "O(n)", space: "O(1)" },
      { op: "isEmpty", time: "O(1)", space: "O(1)" },
      { op: "Size", time: "O(1)", space: "O(1)" },
    ],
    codeExample: `# Stack in Python (using list)
stack = []

# Push elements
stack.append(10)
stack.append(20)
stack.append(30)
print(stack)  # [10, 20, 30]

# Pop (remove top)
top = stack.pop()  # 30
print(stack)  # [10, 20]

# Peek (view top without removing)
print(stack[-1])  # 20

# Valid Parentheses — classic stack problem
def is_valid(s):
    stack = []
    mapping = {')': '(', '}': '{', ']': '['}
    for char in s:
        if char in mapping:
            if not stack or stack[-1] != mapping[char]:
                return False
            stack.pop()
        else:
            stack.append(char)
    return len(stack) == 0

print(is_valid("({[]})"))  # True
print(is_valid("({[)"))    # False

# Next Greater Element using Monotonic Stack
def next_greater(arr):
    result = [-1] * len(arr)
    stack = []
    for i in range(len(arr)):
        while stack and arr[i] > arr[stack[-1]]:
            result[stack.pop()] = arr[i]
        stack.append(i)
    return result

print(next_greater([4, 5, 2, 10]))  # [5, 10, 10, -1]`,
  },

  queue: {
    title: "Queue",
    intro: "A queue is a First-In-First-Out (FIFO) data structure. The first element added is the first one removed — like a line at a ticket counter. Elements are added at the rear and removed from the front.",
    analogy: "🎟️ Think of a line at a movie theater. The first person in line gets served first. New people join at the back. Nobody cuts the line! That's FIFO — First In, First Out. A priority queue is like a VIP line where important people get served first regardless of arrival.",
    steps: [
      "Enqueue: add element to the rear — O(1)",
      "Dequeue: remove element from the front — O(1)",
      "Front/Peek: view front element without removing — O(1)",
      "Deque (double-ended queue): insert/remove from both ends",
      "Priority Queue: elements have priorities, highest priority dequeued first",
      "BFS (Breadth-First Search) uses a queue to explore level by level",
    ],
    complexity: [
      { op: "Enqueue", time: "O(1)", space: "O(1)" },
      { op: "Dequeue", time: "O(1)", space: "O(1)" },
      { op: "Peek / Front", time: "O(1)", space: "O(1)" },
      { op: "Search", time: "O(n)", space: "O(1)" },
      { op: "Priority Queue Insert", time: "O(log n)", space: "O(1)" },
      { op: "Priority Queue Extract", time: "O(log n)", space: "O(1)" },
    ],
    codeExample: `# Queue in Python
from collections import deque

# Basic Queue
queue = deque()
queue.append(10)    # enqueue
queue.append(20)
queue.append(30)
print(queue)  # deque([10, 20, 30])

front = queue.popleft()  # dequeue -> 10
print(queue)  # deque([20, 30])

# BFS using Queue (Level Order Traversal)
def bfs(graph, start):
    visited = set([start])
    queue = deque([start])
    order = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return order

graph = {0: [1, 2], 1: [3], 2: [4], 3: [], 4: []}
print(bfs(graph, 0))  # [0, 1, 2, 3, 4]

# Priority Queue (Min-Heap)
import heapq

pq = []
heapq.heappush(pq, (3, "low"))
heapq.heappush(pq, (1, "high"))
heapq.heappush(pq, (2, "medium"))

while pq:
    priority, task = heapq.heappop(pq)
    print(f"{task} (priority {priority})")
# high (1), medium (2), low (3)`,
  },

  trees: {
    title: "Trees",
    intro: "A tree is a hierarchical data structure consisting of nodes connected by edges. It has a root node at the top, and each node can have zero or more children. Binary trees (max 2 children per node) are the most common variant.",
    analogy: "🌳 Think of a family tree. The grandparent is the root. They have children, who have their own children. Each person knows their parent and children. To find a specific person, you start from the root and traverse down the branches.",
    steps: [
      "Root: the topmost node with no parent",
      "Binary Tree: each node has at most 2 children (left and right)",
      "BST (Binary Search Tree): left child < parent < right child — enables fast search",
      "Traversals: Inorder (L-Root-R), Preorder (Root-L-R), Postorder (L-R-Root), Level-order (BFS)",
      "Height of tree = longest path from root to leaf",
      "Balanced BST (AVL, Red-Black) guarantees O(log n) operations",
    ],
    complexity: [
      { op: "BST Search", time: "O(log n) avg", space: "O(log n)" },
      { op: "BST Insert", time: "O(log n) avg", space: "O(log n)" },
      { op: "BST Delete", time: "O(log n) avg", space: "O(log n)" },
      { op: "Traversal (any)", time: "O(n)", space: "O(n)" },
      { op: "Find height", time: "O(n)", space: "O(n)" },
      { op: "Unbalanced BST worst", time: "O(n)", space: "O(n)" },
    ],
    codeExample: `# Binary Tree in Python

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

# Build tree:     1
#               /   \\
#              2     3
#             / \\
#            4   5
root = TreeNode(1,
    TreeNode(2, TreeNode(4), TreeNode(5)),
    TreeNode(3))

# Inorder Traversal (Left, Root, Right)
def inorder(node):
    if not node: return []
    return inorder(node.left) + [node.val] + inorder(node.right)

print(inorder(root))  # [4, 2, 5, 1, 3]

# Max Depth of Binary Tree
def max_depth(node):
    if not node: return 0
    return 1 + max(max_depth(node.left), max_depth(node.right))

print(max_depth(root))  # 3

# Level Order Traversal (BFS)
from collections import deque
def level_order(root):
    if not root: return []
    result, queue = [], deque([root])
    while queue:
        level = []
        for _ in range(len(queue)):
            node = queue.popleft()
            level.append(node.val)
            if node.left: queue.append(node.left)
            if node.right: queue.append(node.right)
        result.append(level)
    return result

print(level_order(root))  # [[1], [2, 3], [4, 5]]`,
  },

  graphs: {
    title: "Graphs",
    intro: "A graph is a collection of nodes (vertices) connected by edges. Unlike trees, graphs can have cycles, multiple paths between nodes, and no hierarchical structure. They model real-world networks like social media, maps, and the internet.",
    analogy: "🗺️ Think of a city map. Each intersection is a node, and each road is an edge. Some roads are one-way (directed graph), some are two-way (undirected). You might want to find the shortest route between two places — that's a graph problem!",
    steps: [
      "Vertices (nodes) and Edges (connections) are the building blocks",
      "Directed vs Undirected: edges can be one-way or two-way",
      "Weighted vs Unweighted: edges can have costs/distances",
      "Representations: Adjacency List (efficient) vs Adjacency Matrix (simple)",
      "BFS: explore level by level — good for shortest path in unweighted graphs",
      "DFS: explore as deep as possible — good for cycle detection, topological sort",
    ],
    complexity: [
      { op: "BFS / DFS", time: "O(V + E)", space: "O(V)" },
      { op: "Dijkstra's", time: "O((V+E) log V)", space: "O(V)" },
      { op: "Bellman-Ford", time: "O(V × E)", space: "O(V)" },
      { op: "Floyd-Warshall", time: "O(V³)", space: "O(V²)" },
      { op: "Topological Sort", time: "O(V + E)", space: "O(V)" },
      { op: "Union-Find", time: "O(α(n)) ≈ O(1)", space: "O(V)" },
    ],
    codeExample: `# Graph Algorithms in Python
from collections import deque, defaultdict

# Adjacency List representation
graph = defaultdict(list)
edges = [(0,1), (0,2), (1,3), (2,4), (3,4)]
for u, v in edges:
    graph[u].append(v)
    graph[v].append(u)

# BFS — Shortest Path (unweighted)
def bfs(graph, start, target):
    visited = {start}
    queue = deque([(start, [start])])
    while queue:
        node, path = queue.popleft()
        if node == target:
            return path
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))
    return []

print(bfs(graph, 0, 4))  # [0, 2, 4]

# DFS — Cycle Detection
def has_cycle(graph, n):
    visited = set()
    def dfs(node, parent):
        visited.add(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                if dfs(neighbor, node): return True
            elif neighbor != parent:
                return True
        return False
    return dfs(0, -1)

# Dijkstra's Algorithm
import heapq
def dijkstra(graph, start):
    dist = {start: 0}
    pq = [(0, start)]
    while pq:
        d, u = heapq.heappop(pq)
        if d > dist.get(u, float('inf')): continue
        for v, w in graph[u]:
            if d + w < dist.get(v, float('inf')):
                dist[v] = d + w
                heapq.heappush(pq, (d + w, v))
    return dist`,
  },

  "dynamic-programming": {
    title: "Dynamic Programming",
    intro: "Dynamic Programming (DP) is a technique for solving problems by breaking them into overlapping subproblems, solving each subproblem once, and storing results to avoid redundant computation. It turns exponential brute force into polynomial time.",
    analogy: "📝 Imagine calculating Fibonacci numbers. To find F(5), you need F(4) + F(3). To find F(4), you need F(3) + F(2). Notice F(3) is calculated twice! DP says: 'Write it down the first time, and just look it up next time.' That's memoization!",
    steps: [
      "Identify overlapping subproblems — same computation repeated multiple times",
      "Define the state: what variables describe a subproblem uniquely",
      "Write the recurrence relation: how larger problems relate to smaller ones",
      "Top-down (memoization): recursive + cache results in a dictionary/array",
      "Bottom-up (tabulation): iteratively fill a table from smallest to largest subproblem",
      "Optimize space: often you only need the last 1-2 rows/values, not the entire table",
    ],
    complexity: [
      { op: "Fibonacci (naive)", time: "O(2ⁿ)", space: "O(n)" },
      { op: "Fibonacci (DP)", time: "O(n)", space: "O(1)" },
      { op: "0/1 Knapsack", time: "O(n × W)", space: "O(n × W)" },
      { op: "Longest Common Subsequence", time: "O(n × m)", space: "O(n × m)" },
      { op: "Coin Change", time: "O(n × amount)", space: "O(amount)" },
      { op: "Longest Increasing Subseq", time: "O(n log n)", space: "O(n)" },
    ],
    codeExample: `# Dynamic Programming in Python

# Fibonacci — Top-Down (Memoization)
def fib_memo(n, memo={}):
    if n <= 1: return n
    if n not in memo:
        memo[n] = fib_memo(n-1) + fib_memo(n-2)
    return memo[n]

# Fibonacci — Bottom-Up (Tabulation)
def fib_tab(n):
    if n <= 1: return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

print(fib_tab(10))  # 55

# Coin Change — Minimum coins to make amount
def coin_change(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for coin in coins:
        for x in range(coin, amount + 1):
            dp[x] = min(dp[x], dp[x - coin] + 1)
    return dp[amount] if dp[amount] != float('inf') else -1

print(coin_change([1, 5, 10, 25], 30))  # 2 (25 + 5)

# Longest Common Subsequence
def lcs(s1, s2):
    m, n = len(s1), len(s2)
    dp = [[0] * (n+1) for _ in range(m+1)]
    for i in range(1, m+1):
        for j in range(1, n+1):
            if s1[i-1] == s2[j-1]:
                dp[i][j] = dp[i-1][j-1] + 1
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])
    return dp[m][n]

print(lcs("abcde", "ace"))  # 3`,
  },
};
