import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, Bookmark, BookmarkCheck, ExternalLink, Shuffle, Filter, ArrowUpDown, Star } from "lucide-react";
import { problems } from "@/data/problems";
import { useLocalStorage } from "@/hooks/useLocalStorage";

type SortMode = "default" | "easy-hard" | "hard-easy" | "a-z" | "z-a";

export default function PracticePage() {
  const [search, setSearch] = useState("");
  const [diffFilter, setDiffFilter] = useState<string>("All");
  const [topicFilter, setTopicFilter] = useState<string>("All");
  const [sortMode, setSortMode] = useState<SortMode>("default");
  const [showBookmarked, setShowBookmarked] = useState(false);
  const [bookmarks, setBookmarks] = useLocalStorage<number[]>("algo-bookmarks", []);
  const [solved, setSolved] = useLocalStorage<number[]>("algo-solved", []);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    problems.forEach(p => p.tags.forEach(t => tags.add(t)));
    return ["All", ...Array.from(tags).sort()];
  }, []);

  // Daily challenge — deterministic based on date
  const dailyProblem = useMemo(() => {
    const today = new Date();
    const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
    return problems[seed % problems.length];
  }, []);

  const diffOrder = { Easy: 0, Medium: 1, Hard: 2 };

  const filtered = useMemo(() => {
    let result = problems.filter(p => {
      if (search && !p.title.toLowerCase().includes(search.toLowerCase()) && !p.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))) return false;
      if (diffFilter !== "All" && p.difficulty !== diffFilter) return false;
      if (topicFilter !== "All" && !p.tags.includes(topicFilter)) return false;
      if (showBookmarked && !bookmarks.includes(p.id)) return false;
      return true;
    });

    switch (sortMode) {
      case "easy-hard": result.sort((a, b) => diffOrder[a.difficulty] - diffOrder[b.difficulty]); break;
      case "hard-easy": result.sort((a, b) => diffOrder[b.difficulty] - diffOrder[a.difficulty]); break;
      case "a-z": result.sort((a, b) => a.title.localeCompare(b.title)); break;
      case "z-a": result.sort((a, b) => b.title.localeCompare(a.title)); break;
    }
    return result;
  }, [search, diffFilter, topicFilter, sortMode, showBookmarked, bookmarks]);

  const toggleBookmark = (id: number) => {
    setBookmarks(prev => prev.includes(id) ? prev.filter(b => b !== id) : [...prev, id]);
  };

  const diffBadge = (d: string) => {
    if (d === "Easy") return "algo-badge-easy";
    if (d === "Medium") return "algo-badge-medium";
    return "algo-badge-hard";
  };

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between mb-2 flex-wrap gap-4">
          <h1 className="text-3xl font-bold">Practice Problems</h1>
        </div>
        <p className="text-muted-foreground mb-6">Sharpen your skills with {problems.length} curated problems</p>
      </motion.div>

      {/* Daily Challenge */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="algo-card p-4 mb-6 border-l-4"
        style={{ borderLeftColor: "hsl(var(--primary))" }}
      >
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="text-2xl">🔥</div>
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-primary mb-0.5">Daily Challenge</div>
              <div className="font-medium">{dailyProblem.title}</div>
            </div>
            <span className={diffBadge(dailyProblem.difficulty)}>{dailyProblem.difficulty}</span>
          </div>
          <Link
            to={`/practice/${dailyProblem.id}`}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-primary-foreground"
            style={{ background: "var(--gradient-primary)" }}
          >
            Solve Now →
          </Link>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search problems or topics..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <select
            value={diffFilter}
            onChange={e => setDiffFilter(e.target.value)}
            className="px-3 py-2.5 rounded-lg border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            {["All", "Easy", "Medium", "Hard"].map(d => (
              <option key={d} value={d}>{d === "All" ? "All Difficulties" : d}</option>
            ))}
          </select>

          <select
            value={topicFilter}
            onChange={e => setTopicFilter(e.target.value)}
            className="px-3 py-2.5 rounded-lg border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            {allTags.map(t => (
              <option key={t} value={t}>{t === "All" ? "All Topics" : t}</option>
            ))}
          </select>

          <div className="flex items-center gap-1">
            <ArrowUpDown className="w-4 h-4 text-muted-foreground" />
            <select
              value={sortMode}
              onChange={e => setSortMode(e.target.value as SortMode)}
              className="px-3 py-2.5 rounded-lg border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
            >
              <option value="default">Default</option>
              <option value="easy-hard">Easy → Hard</option>
              <option value="hard-easy">Hard → Easy</option>
              <option value="a-z">A → Z</option>
              <option value="z-a">Z → A</option>
            </select>
          </div>

          <button
            onClick={() => setShowBookmarked(!showBookmarked)}
            className={`inline-flex items-center gap-1.5 px-3 py-2.5 rounded-lg text-sm font-medium border transition-all ${
              showBookmarked ? "border-primary bg-primary/10 text-primary" : "border-border bg-card hover:bg-muted"
            }`}
          >
            <Star className="w-3.5 h-3.5" /> Bookmarked
          </button>
        </div>
      </div>

      {/* Stats bar */}
      <div className="flex gap-4 mb-6 text-sm">
        <span className="text-muted-foreground">
          Showing <span className="font-semibold text-foreground">{filtered.length}</span> problems
        </span>
        <span className="text-muted-foreground">
          · <span className="font-semibold text-primary">{solved.length}</span> solved
        </span>
        <span className="text-muted-foreground">
          · <span className="font-semibold text-accent">{bookmarks.length}</span> bookmarked
        </span>
      </div>

      {/* Problem List */}
      <div className="space-y-3">
        {filtered.map((problem, i) => (
          <motion.div
            key={problem.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.02 }}
            className="algo-card p-4 flex items-center gap-4"
          >
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
              solved.includes(problem.id)
                ? "bg-primary/15 text-primary"
                : "bg-muted text-muted-foreground"
            }`}>
              {solved.includes(problem.id) ? "✓" : problem.id}
            </div>

            <Link to={`/practice/${problem.id}`} className="flex-1 min-w-0">
              <h3 className="font-medium text-sm hover:text-primary transition-colors truncate">{problem.title}</h3>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <span className={diffBadge(problem.difficulty)}>{problem.difficulty}</span>
                {problem.tags.map(tag => (
                  <span key={tag} className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">
                    {tag}
                  </span>
                ))}
              </div>
            </Link>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => toggleBookmark(problem.id)}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
              >
                {bookmarks.includes(problem.id) ? (
                  <BookmarkCheck className="w-4 h-4 text-primary" />
                ) : (
                  <Bookmark className="w-4 h-4 text-muted-foreground" />
                )}
              </button>
              <a
                href={problem.externalLink}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <ExternalLink className="w-4 h-4 text-muted-foreground" />
              </a>
            </div>
          </motion.div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="algo-card p-12 text-center">
          <div className="text-4xl mb-4">🔍</div>
          <p className="text-muted-foreground">No problems match your filters</p>
        </div>
      )}
    </div>
  );
}
